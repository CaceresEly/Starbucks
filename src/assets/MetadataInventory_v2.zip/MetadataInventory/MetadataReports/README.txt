Reports, logs and diagnostic packages are written to this folder.
