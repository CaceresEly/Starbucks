@echo off
setlocal EnableExtensions DisableDelayedExpansion
set "PKG=%~dp0"
set "SCRIPT=%PKG%ExportMetadataInventory.ps1"
set "MODULE=%PKG%Modules\ImportExcel\7.8.10\ImportExcel.psd1"
set "PSEXE=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
if not exist "%PSEXE%" set "PSEXE=powershell.exe"
set "RC=5"
title Metadata Inventory
echo ============================================================
echo   METADATA INVENTORY - read-only, no SharePoint upload
echo ============================================================
echo.
echo  - Only rows where "To Be Uploaded?" = "Yes" are processed.
echo  - Nothing is uploaded, modified, moved, renamed or deleted.
echo  - Results are written to the MetadataReports folder.
echo  - A file selection window will open. It may appear behind
echo    this window: check the taskbar if you do not see it.
echo  - Do NOT run this file "as administrator": mapped drives are
echo    usually not visible in an administrator session.
echo.

if not exist "%SCRIPT%" goto :missing_script
if not exist "%MODULE%" goto :missing_module

pushd "%PKG%" >nul 2>&1
"%PSEXE%" -NoProfile -NoLogo -ExecutionPolicy Bypass -STA -File "%SCRIPT%" %*
set "RC=%ERRORLEVEL%"
popd >nul 2>&1

echo.
echo ============================================================
if "%RC%"=="0" echo   RESULT: SUCCESS - the inventory completed without errors.
if "%RC%"=="1" echo   RESULT: COMPLETED WITH ERRORS - items were exported, but
if "%RC%"=="1" echo           some sources or folders failed. See the Errors CSV.
if "%RC%"=="2" echo   RESULT: FAILED - ZERO ITEMS WERE EXPORTED.
if "%RC%"=="2" echo           Run RunDiagnostic.bat and send the diagnostic ZIP.
if "%RC%"=="3" echo   RESULT: NOTHING TO PROCESS - no valid "Yes" rows or paths.
if "%RC%"=="4" echo   RESULT: CANCELLED - no Excel workbook was selected.
if "%RC%"=="5" echo   RESULT: FATAL ERROR - see the log file in MetadataReports.
echo   PowerShell exit code: %RC%
echo   Reports folder: "%PKG%MetadataReports"
echo   Send the newest MetadataInventory_SendThis_*.zip from that folder.
echo ============================================================
if not defined METADATA_INVENTORY_NOPAUSE if exist "%PKG%MetadataReports" start "" explorer.exe "%PKG%MetadataReports"
goto :end

:missing_script
echo ERROR: ExportMetadataInventory.ps1 was not found next to this BAT file.
echo Extract the COMPLETE ZIP package to a normal folder first, then run the BAT file
echo from the extracted folder. Do not run it from inside the ZIP viewer.
set "RC=5"
goto :end

:missing_module
echo ERROR: The bundled ImportExcel module was not found:
echo   Modules\ImportExcel\7.8.10\ImportExcel.psd1
echo Extract the COMPLETE ZIP package, keeping the folder structure.
set "RC=5"
goto :end

:end
echo.
if not defined METADATA_INVENTORY_NOPAUSE pause
endlocal & exit /b %RC%
