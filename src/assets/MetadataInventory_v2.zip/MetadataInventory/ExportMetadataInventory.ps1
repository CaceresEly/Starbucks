#Requires -Version 5.1
<#
.SYNOPSIS
    Read-only metadata inventory of the files and folders referenced by a migration Excel workbook.

.DESCRIPTION
    ARLANXEO TSPortal migration - Metadata Inventory tool.

    - Lets the user pick the migration workbook (.xlsx / .xlsm) and reads the "MetaData" worksheet.
    - Processes only rows where "To Be Uploaded?" = "Yes".
    - Source path priority: "Source Folder", then "UNC Source Folder", then "UNC Folder".
      A fallback column is only used when it demonstrably points to the same location.
    - Validates every source root BEFORE deduplication, with several access methods
      (original path, path resolved from the drive mapping, Excel UNC fallback; extended-length
      and plain forms), and records exactly which method worked or why each one failed.
    - Enumerates folders with the native Win32 API (FindFirstFileExW) so the result does not depend
      on the .NET path-handling mode of Windows PowerShell 5.1. Long paths are supported.
    - Writes a UTF-8 (with BOM), semicolon-delimited inventory CSV, an errors CSV, a per-row
      sources CSV, a summary and a log.
    - Never connects to SharePoint, never uploads, and never modifies, moves, renames or deletes
      source files. It only lists directories and reads file-system metadata.

    Use -DiagnosticOnly to test path resolution and access without running the full inventory.

.PARAMETER SheetName
    Worksheet to read. Default: MetaData.

.PARAMETER ExcelPath
    Optional path of the workbook. When omitted, a file-selection dialog is shown.

.PARAMETER DiagnosticOnly
    Reads the workbook, validates source paths, collects environment and network diagnostics,
    writes a diagnostic package (ZIP) and exits without the recursive inventory.

.PARAMETER OutputFolder
    Optional output folder. Default: the MetadataReports folder next to this script.

.PARAMETER LocalizedExcelCopy
    Also writes a second inventory CSV whose SizeMB column uses the decimal separator of the
    current Windows regional settings (for double-click opening in Excel). The main CSV is
    always culture-invariant (dot as decimal separator).

.PARAMETER AllowNonEquivalentFallback
    Allows the UNC fallback columns to be used even when they do not demonstrably point to the
    same location as "Source Folder". Off by default.

.PARAMETER DiagnosticMaxRoots
    Maximum number of top-level source roots that receive the full access-method matrix in
    diagnostic mode. Default: 200.

.PARAMETER FileSystemEngine
    Auto (default): native Win32 engine, falling back to .NET if it cannot be loaded.
    Win32 / DotNet: force an engine (troubleshooting only).

.PARAMETER LoadFunctionsOnly
    Loads the functions without running anything (used by the automated tests).

.EXAMPLE
    .\ExportMetadataInventory.ps1

.EXAMPLE
    .\ExportMetadataInventory.ps1 -DiagnosticOnly

.NOTES
    Exit codes:
      0 = Success (diagnostic: all source roots accessible)
      1 = Completed with errors (diagnostic: some source roots inaccessible)
      2 = Failed: zero items exported / no source root accessible
      3 = Nothing to process (no "Yes" rows or no valid source paths)
      4 = Cancelled by the user
      5 = Fatal error (missing module, unreadable workbook, unexpected exception)
#>
[CmdletBinding()]
param(
    [string]$SheetName = 'MetaData',
    [string]$ExcelPath = '',
    [switch]$DiagnosticOnly,
    [string]$OutputFolder = '',
    [switch]$LocalizedExcelCopy,
    [switch]$AllowNonEquivalentFallback,
    [ValidateRange(1, 100000)][int]$DiagnosticMaxRoots = 200,
    [ValidateSet('Auto', 'Win32', 'DotNet')][string]$FileSystemEngine = 'Auto',
    [switch]$LoadFunctionsOnly
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

# ============================================================================
# Constants
# ============================================================================
$script:ScriptVersion = '2.0.4'
$script:ScriptBase = $PSScriptRoot
$script:Invariant = [System.Globalization.CultureInfo]::InvariantCulture
$script:Utf8Bom = New-Object System.Text.UTF8Encoding($true)
$script:OrdinalIgnoreCase = [System.StringComparison]::OrdinalIgnoreCase
$script:State = $null

$script:ExitCodes = @{
    Success          = 0
    PartialSuccess   = 1
    Failed           = 2
    NothingToProcess = 3
    Cancelled        = 4
    FatalError       = 5
}

$script:InventoryColumns = @(
    'ItemType', 'Name', 'BaseName', 'Extension',
    'FullPath', 'ParentPath', 'SourceRoot', 'RelativePath', 'DepthFromSourceRoot',
    'SizeMB',
    'CreationTime', 'LastWriteTime', 'LastAccessTime',
    'CreationTimeUtc', 'LastWriteTimeUtc', 'LastAccessTimeUtc',
    'PathLength', 'NameLength', 'Attributes',
    'ExcelRow', 'IsRootFromExcel'
)

# The first four columns keep the layout of the previous error report.
$script:IssueColumns = @(
    'ExcelRow', 'SourcePath', 'ItemPath', 'Error',
    'Severity', 'Phase', 'Category', 'Win32Code', 'ExceptionType',
    'AccessPath', 'AccessMethod', 'AttemptDetails', 'Timestamp'
)

$script:SourceColumns = @(
    'ExcelRow', 'Status', 'Detail',
    'SourceFolder', 'UncSourceFolder', 'UncFolder',
    'SelectedColumn', 'LogicalPath', 'CanonicalPath', 'PathKind', 'FallbackEquivalence',
    'AccessPath', 'AccessMethod', 'ItemKind', 'Category', 'Win32Code',
    'CoveredByRow', 'CoveredByPath', 'DuplicateOfRow', 'ExcelOriginFiles', 'AttemptDetails'
)

$script:DiagnosticTestColumns = @(
    'Scope', 'ExcelRow', 'LogicalPath', 'Variant', 'Form', 'TestedPath', 'Method',
    'Result', 'Win32Code', 'Category', 'ExceptionType', 'Message', 'DurationMs'
)

$script:ExcelColumnNames = @{
    ToBeUploaded    = 'To Be Uploaded?'
    SourceFolder    = 'Source Folder'
    UncSourceFolder = 'UNC Source Folder'
    UncFolder       = 'UNC Folder'
    OriginFiles     = '# Origin Files'
}

$script:InvalidSegmentChars = [char[]]@('<', '>', ':', '"', '|', '?', '*')

$script:EquivalentFallbackKinds = @(
    'VerifiedByDriveMapping', 'SameRelativePath',
    'SameRelativePathDriveMappedElsewhere', 'SameShareDifferentServerName'
)

# Failures that mean "nothing below this path can be reached through this route".
$script:NetworkCategories = @('ServerUnreachable', 'ShareNotFound', 'AuthenticationFailure', 'NetworkError')

# Used to choose the most informative reason when several access attempts failed.
$script:CategoryPriority = @(
    'AccessDenied', 'AuthenticationFailure', 'NotFound', 'ShareNotFound', 'ServerUnreachable',
    'NetworkError', 'PathTooLong', 'CloudFileUnavailable', 'InvalidPath', 'DriveNotMapped', 'Other'
)

$script:CategoryDescriptions = @{
    NotFound              = 'The folder or file does not exist (the server answered, but the path was not found).'
    AccessDenied          = 'The path exists, but the current Windows user is not allowed to read or list it.'
    DriveNotMapped        = 'The drive letter is not mapped in this PowerShell session.'
    ServerUnreachable     = 'The server name could not be resolved or reached (DNS or SMB connectivity).'
    ShareNotFound         = 'The server answered, but the share name does not exist.'
    AuthenticationFailure = 'Windows could not authenticate to the server (credentials, Kerberos or logon session).'
    NetworkError          = 'Network error while contacting the server (timeout, connection reset or network unavailable).'
    InvalidPath           = 'The path syntax is not valid for this access method.'
    PathTooLong           = 'The path is too long for this access method.'
    CloudFileUnavailable  = 'The cloud file provider (for example OneDrive) is not available.'
    Other                 = 'Unexpected error.'
    NotAttempted          = 'No access method could be attempted.'
}

$script:Win32CategoryMap = @{
    2 = 'NotFound'; 3 = 'NotFound'; 5 = 'AccessDenied'; 15 = 'DriveNotMapped'; 21 = 'DriveNotMapped'
    50 = 'Other'; 51 = 'ServerUnreachable'; 53 = 'ServerUnreachable'; 59 = 'NetworkError'; 64 = 'NetworkError'
    65 = 'AccessDenied'; 67 = 'ShareNotFound'; 86 = 'AuthenticationFailure'; 87 = 'InvalidPath'
    121 = 'NetworkError'; 123 = 'InvalidPath'; 161 = 'InvalidPath'; 206 = 'PathTooLong'; 267 = 'InvalidPath'
    362 = 'CloudFileUnavailable'; 1201 = 'DriveNotMapped'; 1203 = 'ServerUnreachable'
    1219 = 'AuthenticationFailure'; 1222 = 'NetworkError'; 1231 = 'NetworkError'; 1232 = 'NetworkError'
    1311 = 'AuthenticationFailure'; 1326 = 'AuthenticationFailure'; 1327 = 'AuthenticationFailure'
    1328 = 'AuthenticationFailure'; 1329 = 'AuthenticationFailure'; 1330 = 'AuthenticationFailure'
    1331 = 'AuthenticationFailure'; 1385 = 'AuthenticationFailure'; 1907 = 'AuthenticationFailure'
    1909 = 'AuthenticationFailure'; 1920 = 'AccessDenied'; 2250 = 'DriveNotMapped'
}

$script:AttributeNames = @(
    @(0x1, 'ReadOnly'), @(0x2, 'Hidden'), @(0x4, 'System'), @(0x10, 'Directory'),
    @(0x20, 'Archive'), @(0x40, 'Device'), @(0x80, 'Normal'), @(0x100, 'Temporary'),
    @(0x200, 'SparseFile'), @(0x400, 'ReparsePoint'), @(0x800, 'Compressed'), @(0x1000, 'Offline'),
    @(0x2000, 'NotContentIndexed'), @(0x4000, 'Encrypted'), @(0x8000, 'IntegrityStream'),
    @(0x10000, 'Virtual'), @(0x20000, 'NoScrubData'), @(0x40000, 'RecallOnOpen'),
    @(0x80000, 'Pinned'), @(0x100000, 'Unpinned'), @(0x400000, 'RecallOnDataAccess')
)
$script:AttributeCache = @{}
$script:Win32MessageCache = @{}

# Bits that identify cloud placeholders (OneDrive / Files On-Demand) when the reparse tag is unknown.
$script:CloudAttributeMask = 0x1000 -bor 0x40000 -bor 0x80000 -bor 0x100000 -bor 0x400000

# ============================================================================
# Native read-only file-system engine (C# 5 syntax so that Windows PowerShell 5.1 can compile it)
# Only FindFirstFileExW / FindNextFileW / FindClose / GetFileAttributesExW / WNetGetConnectionW are
# used. None of them opens, modifies or hydrates files.
# ============================================================================
$script:NativeSource = @'
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Text;

namespace MetadataInventoryNative
{
    public sealed class FsEntry
    {
        public string Name;
        public uint Attributes;
        public long Size;
        public long CreationFileTime;
        public long LastAccessFileTime;
        public long LastWriteFileTime;
        public uint ReparseTag;

        public bool IsDirectory { get { return (Attributes & 0x10u) != 0u; } }
        public bool IsReparsePoint { get { return (Attributes & 0x400u) != 0u; } }
        public bool IsNameSurrogate { get { return IsReparsePoint && (ReparseTag & 0x20000000u) != 0u; } }
    }

    public sealed class FsListResult
    {
        public List<FsEntry> Entries;
        public int ErrorCode;
        public bool Partial;

        public FsListResult()
        {
            Entries = new List<FsEntry>();
            ErrorCode = 0;
            Partial = false;
        }
    }

    public static class Win32Fs
    {
        private const int FindExInfoStandard = 0;
        private const int FindExInfoBasic = 1;
        private const int FindExSearchNameMatch = 0;
        private const int FindFirstExLargeFetch = 2;
        private const int ErrorFileNotFound = 2;
        private const int ErrorNoMoreFiles = 18;
        private const int ErrorInvalidParameter = 87;
        private const int ErrorInvalidLevel = 124;
        private const int ErrorMoreData = 234;
        private const int ErrorConnectionUnavailable = 1201;
        private static readonly IntPtr InvalidHandleValue = new IntPtr(-1);

        [StructLayout(LayoutKind.Sequential)]
        private struct NativeFileTime
        {
            public uint Low;
            public uint High;
        }

        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
        private struct Win32FindData
        {
            public uint dwFileAttributes;
            public NativeFileTime ftCreationTime;
            public NativeFileTime ftLastAccessTime;
            public NativeFileTime ftLastWriteTime;
            public uint nFileSizeHigh;
            public uint nFileSizeLow;
            public uint dwReserved0;
            public uint dwReserved1;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 260)]
            public string cFileName;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 14)]
            public string cAlternateFileName;
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct Win32FileAttributeData
        {
            public uint dwFileAttributes;
            public NativeFileTime ftCreationTime;
            public NativeFileTime ftLastAccessTime;
            public NativeFileTime ftLastWriteTime;
            public uint nFileSizeHigh;
            public uint nFileSizeLow;
        }

        [DllImport("kernel32.dll", EntryPoint = "FindFirstFileExW", CharSet = CharSet.Unicode, SetLastError = true)]
        private static extern IntPtr FindFirstFileExNative(string fileName, int infoLevel, out Win32FindData findData, int searchOp, IntPtr searchFilter, int additionalFlags);

        [DllImport("kernel32.dll", EntryPoint = "FindNextFileW", CharSet = CharSet.Unicode, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool FindNextFileNative(IntPtr findHandle, out Win32FindData findData);

        [DllImport("kernel32.dll", EntryPoint = "FindClose", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool FindCloseNative(IntPtr findHandle);

        [DllImport("kernel32.dll", EntryPoint = "GetFileAttributesExW", CharSet = CharSet.Unicode, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool GetFileAttributesExNative(string fileName, int infoLevel, out Win32FileAttributeData fileData);

        [DllImport("mpr.dll", EntryPoint = "WNetGetConnectionW", CharSet = CharSet.Unicode)]
        private static extern int WNetGetConnectionNative(string localName, StringBuilder remoteName, ref int length);

        private static long CombineFileTime(NativeFileTime value)
        {
            return ((long)value.High << 32) | (long)value.Low;
        }

        private static long CombineSize(uint high, uint low)
        {
            return ((long)high << 32) | (long)low;
        }

        private static string BuildPattern(string directoryPath)
        {
            if (directoryPath.EndsWith("\\", StringComparison.Ordinal))
            {
                return directoryPath + "*";
            }
            return directoryPath + "\\*";
        }

        private static IntPtr OpenSearch(string pattern, out Win32FindData data, out int errorCode)
        {
            IntPtr handle = FindFirstFileExNative(pattern, FindExInfoBasic, out data, FindExSearchNameMatch, IntPtr.Zero, FindFirstExLargeFetch);
            if (handle != InvalidHandleValue)
            {
                errorCode = 0;
                return handle;
            }
            errorCode = Marshal.GetLastWin32Error();
            if (errorCode == ErrorInvalidParameter || errorCode == ErrorInvalidLevel)
            {
                handle = FindFirstFileExNative(pattern, FindExInfoStandard, out data, FindExSearchNameMatch, IntPtr.Zero, 0);
                if (handle != InvalidHandleValue)
                {
                    errorCode = 0;
                    return handle;
                }
                errorCode = Marshal.GetLastWin32Error();
            }
            return handle;
        }

        private static FsEntry ToEntry(Win32FindData data)
        {
            FsEntry entry = new FsEntry();
            entry.Name = data.cFileName;
            entry.Attributes = data.dwFileAttributes;
            entry.Size = ((data.dwFileAttributes & 0x10u) != 0u) ? 0L : CombineSize(data.nFileSizeHigh, data.nFileSizeLow);
            entry.CreationFileTime = CombineFileTime(data.ftCreationTime);
            entry.LastAccessFileTime = CombineFileTime(data.ftLastAccessTime);
            entry.LastWriteFileTime = CombineFileTime(data.ftLastWriteTime);
            entry.ReparseTag = ((data.dwFileAttributes & 0x400u) != 0u) ? data.dwReserved0 : 0u;
            return entry;
        }

        // Lists the direct children of a directory. ErrorCode = 0 means success.
        // An empty directory (or a root without "." entries) returns success with no entries.
        public static FsListResult ListDirectory(string directoryPath)
        {
            FsListResult result = new FsListResult();
            Win32FindData data;
            int openError;
            IntPtr handle = OpenSearch(BuildPattern(directoryPath), out data, out openError);
            if (handle == InvalidHandleValue)
            {
                if (openError != ErrorFileNotFound && openError != ErrorNoMoreFiles)
                {
                    result.ErrorCode = openError;
                }
                return result;
            }
            try
            {
                while (true)
                {
                    string name = data.cFileName;
                    if (name != "." && name != "..")
                    {
                        result.Entries.Add(ToEntry(data));
                    }
                    if (!FindNextFileNative(handle, out data))
                    {
                        int nextError = Marshal.GetLastWin32Error();
                        if (nextError != ErrorNoMoreFiles)
                        {
                            result.ErrorCode = nextError;
                            result.Partial = true;
                        }
                        break;
                    }
                }
            }
            finally
            {
                FindCloseNative(handle);
            }
            return result;
        }

        // Returns the raw Win32 result of opening a directory listing:
        // 0 = listing works and returned at least one entry; 2 or 18 = listing works but is empty;
        // any other value = the error code.
        public static int ProbeDirectory(string directoryPath)
        {
            Win32FindData data;
            int openError;
            IntPtr handle = OpenSearch(BuildPattern(directoryPath), out data, out openError);
            if (handle == InvalidHandleValue)
            {
                return openError;
            }
            FindCloseNative(handle);
            return 0;
        }

        // Reads attributes, size and timestamps of a single path without opening it.
        public static FsEntry GetEntry(string path, out int errorCode)
        {
            Win32FileAttributeData data;
            if (!GetFileAttributesExNative(path, 0, out data))
            {
                errorCode = Marshal.GetLastWin32Error();
                return null;
            }
            errorCode = 0;
            FsEntry entry = new FsEntry();
            entry.Name = string.Empty;
            entry.Attributes = data.dwFileAttributes;
            entry.Size = ((data.dwFileAttributes & 0x10u) != 0u) ? 0L : CombineSize(data.nFileSizeHigh, data.nFileSizeLow);
            entry.CreationFileTime = CombineFileTime(data.ftCreationTime);
            entry.LastAccessFileTime = CombineFileTime(data.ftLastAccessTime);
            entry.LastWriteFileTime = CombineFileTime(data.ftLastWriteTime);
            entry.ReparseTag = 0u;
            return entry;
        }

        // Returns the UNC path behind a mapped drive ("Y:") for the current logon session, or null.
        public static string GetDriveRemoteName(string localName, out int errorCode)
        {
            int length = 1024;
            StringBuilder buffer = new StringBuilder(length);
            errorCode = WNetGetConnectionNative(localName, buffer, ref length);
            if (errorCode == ErrorMoreData)
            {
                buffer = new StringBuilder(length + 1);
                errorCode = WNetGetConnectionNative(localName, buffer, ref length);
            }
            if (errorCode != 0 && errorCode != ErrorConnectionUnavailable)
            {
                return null;
            }
            string value = buffer.ToString();
            if (string.IsNullOrEmpty(value))
            {
                return null;
            }
            return value;
        }
    }
}
'@

# ============================================================================
# State
# ============================================================================
function Initialize-InventoryState {
    $comparer = [System.StringComparer]::OrdinalIgnoreCase
    $script:State = @{
        Mode                      = 'Inventory'
        RunTimestamp              = (Get-Date).ToString('yyyyMMdd_HHmmss', $script:Invariant)
        StartTime                 = Get-Date
        Engine                    = 'None'
        EngineDetail              = ''
        DotNetExtendedPathSupport = $null
        Cancelled                 = $false
        FatalError                = $false
        FatalMessage              = ''
        Options                   = @{
            AllowNonEquivalentFallback = $false
            LocalizedExcelCopy         = $false
            DiagnosticMaxRoots         = 200
            Quiet                      = $false
            HostCheck                  = $null
        }
        Paths                     = @{
            OutputFolder  = ''
            InventoryCsv  = ''
            LocalizedCsv  = ''
            IssueCsv      = ''
            SourcesCsv    = ''
            SummaryTxt    = ''
            LogTxt        = ''
            DiagReportTxt = ''
            DiagTestsCsv  = ''
            DiagZip       = ''
            SupportZip    = ''
        }
        LogWriter                 = $null
        InventoryWriter           = $null
        LocalizedWriter           = $null
        IssueWriter               = $null
        PendingIssueLines         = New-Object 'System.Collections.Generic.List[string]'
        Issues                    = New-Object 'System.Collections.Generic.List[object]'
        IssueMemoryLimit          = 20000
        ErrorCount                = 0
        WarningCount              = 0
        InfoCount                 = 0
        ConsoleFailureLines       = 0
        ConsoleRootLines          = 0
        CategoryCounts            = New-Object 'System.Collections.Generic.Dictionary[string,int]'
        DriveCache                = @{}
        DriveWarningsIssued       = @{}
        FailureCacheNetwork       = New-Object 'System.Collections.Generic.Dictionary[string,object]' ($comparer)
        FailureCacheExact         = New-Object 'System.Collections.Generic.Dictionary[string,object]' ($comparer)
        ServerStatus              = New-Object 'System.Collections.Generic.Dictionary[string,object]' ($comparer)
        ImpliedDriveMappings      = @{}
        FailedDirectories         = New-Object 'System.Collections.Generic.Dictionary[string,object]' ($comparer)
        RowByCanonical            = New-Object 'System.Collections.Generic.Dictionary[string,int]' ($comparer)
        Candidates                = New-Object 'System.Collections.Generic.List[object]'
        Roots                     = New-Object 'System.Collections.Generic.List[object]'
        Excel                     = @{
            Path         = ''
            SheetName    = ''
            DataRowsRead = 0
            BlankRows    = 0
            Headers      = @()
            Library      = ''
        }
        Environment               = $null
        Counters                  = @{
            YesRows                  = 0
            RowsWithoutSourcePath    = 0
            RowsWithInvalidPath      = 0
            ValidCandidates          = 0
            UniqueSourcePaths        = 0
            DuplicateRows            = 0
            CoveredRows              = 0
            RootsEvaluated           = 0
            AccessibleRoots          = 0
            InaccessibleRoots        = 0
            RecoveredRoots           = 0
            RootsScanned             = 0
            FilesExported            = 0
            FoldersExported          = 0
            ItemsExported            = 0
            TotalBytes               = [long]0
            DirectoriesEnumerated    = 0
            DirectoryErrors          = 0
            ReparsePointsNotFollowed = 0
            SystemItemsSkipped       = 0
            ExcelEstimateFiles       = [double]0
            ExcelEstimateRows        = 0
        }
        Progress                  = @{
            SourceIndex = 0
            SourceCount = 0
            SourceLabel = ''
            CurrentPath = ''
            QueueCount  = 0
        }
        ProgressWatch             = [System.Diagnostics.Stopwatch]::StartNew()
        HeartbeatWatch            = [System.Diagnostics.Stopwatch]::StartNew()
    }
}

# ============================================================================
# Logging and CSV helpers
# ============================================================================
function Write-Log {
    param(
        [AllowEmptyString()][string]$Message = '',
        [ValidateSet('INFO', 'OK', 'WARN', 'ERROR', 'HEADER', 'DETAIL')][string]$Level = 'INFO',
        [switch]$NoConsole
    )
    $s = $script:State
    if ($null -ne $s -and $null -ne $s.LogWriter) {
        try {
            $stamp = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss', $script:Invariant)
            $s.LogWriter.WriteLine($stamp + ' [' + $Level + '] ' + $Message)
        }
        catch { }
    }
    if ($NoConsole -or $Level -eq 'DETAIL') { return }
    if ($null -ne $s -and $s.Options.Quiet) { return }
    $color = 'Gray'
    switch ($Level) {
        'OK' { $color = 'Green' }
        'WARN' { $color = 'Yellow' }
        'ERROR' { $color = 'Red' }
        'HEADER' { $color = 'Cyan' }
    }
    Write-Host $Message -ForegroundColor $color
}

function ConvertTo-CsvLine {
    param([object[]]$Fields, [string]$Delimiter = ';')
    $text = New-Object 'System.Collections.Generic.List[string]' ($Fields.Count)
    foreach ($f in $Fields) {
        if ($null -eq $f) { $text.Add('') } else { $text.Add(([string]$f).Replace('"', '""')) }
    }
    return '"' + [string]::Join('"' + $Delimiter + '"', $text) + '"'
}

function New-Utf8Writer {
    param([string]$Path, [bool]$AutoFlush = $false)
    $writer = New-Object System.IO.StreamWriter($Path, $false, $script:Utf8Bom, 65536)
    $writer.AutoFlush = $AutoFlush
    return $writer
}

function Format-Count {
    param([double]$Value)
    return $Value.ToString('N0', $script:Invariant)
}

function Format-Bytes {
    param([long]$Bytes)
    $mb = $Bytes / 1048576.0
    $gb = $Bytes / 1073741824.0
    return ('{0} MB ({1} GiB; {2} bytes)' -f $mb.ToString('N3', $script:Invariant), $gb.ToString('N3', $script:Invariant), $Bytes.ToString('N0', $script:Invariant))
}

function Format-Duration {
    param([TimeSpan]$Span)
    return [string]::Format($script:Invariant, '{0:00}:{1:00}:{2:00}', [int][Math]::Floor($Span.TotalHours), $Span.Minutes, $Span.Seconds)
}

function Get-SafeValue {
    param([scriptblock]$Script)
    try {
        $value = & $Script
        if ($null -eq $value) { return '' }
        if ($value -is [string]) { return $value }
        if ($value -is [System.Collections.IEnumerable]) {
            $parts = New-Object 'System.Collections.Generic.List[string]'
            foreach ($item in $value) { $parts.Add([string]$item) }
            return [string]::Join(', ', $parts)
        }
        return [string]$value
    }
    catch {
        return ('<error: ' + $_.Exception.Message + '>')
    }
}

function Add-RunIssue {
    param(
        [ValidateSet('Error', 'Warning', 'Info')][string]$Severity = 'Error',
        [string]$Phase = '',
        [AllowNull()][object]$ExcelRow = '',
        [AllowEmptyString()][string]$SourcePath = '',
        [AllowEmptyString()][string]$ItemPath = '',
        [AllowEmptyString()][string]$Message = '',
        [AllowEmptyString()][string]$Category = '',
        [AllowNull()][object]$Win32Code = '',
        [AllowEmptyString()][string]$ExceptionType = '',
        [AllowEmptyString()][string]$AccessPath = '',
        [AllowEmptyString()][string]$AccessMethod = '',
        [AllowEmptyString()][string]$AttemptDetails = ''
    )
    $s = $script:State
    switch ($Severity) {
        'Error' { $s.ErrorCount = $s.ErrorCount + 1 }
        'Warning' { $s.WarningCount = $s.WarningCount + 1 }
        default { $s.InfoCount = $s.InfoCount + 1 }
    }
    $key = $Severity + ': ' + $(if ($Category) { $Category } else { $Phase })
    if ($s.CategoryCounts.ContainsKey($key)) { $s.CategoryCounts[$key] = $s.CategoryCounts[$key] + 1 } else { $s.CategoryCounts[$key] = 1 }

    $codeText = ''
    if ($null -ne $Win32Code -and [string]$Win32Code -ne '' -and [string]$Win32Code -ne '0') { $codeText = [string]$Win32Code }
    $rowText = ''
    if ($null -ne $ExcelRow) { $rowText = [string]$ExcelRow }
    $record = [pscustomobject]@{
        ExcelRow       = $rowText
        SourcePath     = $SourcePath
        ItemPath       = $ItemPath
        Error          = $Message
        Severity       = $Severity
        Phase          = $Phase
        Category       = $Category
        Win32Code      = $codeText
        ExceptionType  = $ExceptionType
        AccessPath     = $AccessPath
        AccessMethod   = $AccessMethod
        AttemptDetails = $AttemptDetails
        Timestamp      = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss', $script:Invariant)
    }
    if ($s.Issues.Count -lt $s.IssueMemoryLimit) { $s.Issues.Add($record) }

    $fields = New-Object 'System.Collections.Generic.List[object]'
    foreach ($column in $script:IssueColumns) { $fields.Add($record.$column) }
    $line = ConvertTo-CsvLine -Fields $fields.ToArray()
    if ($null -ne $s.IssueWriter) { $s.IssueWriter.WriteLine($line) } else { $s.PendingIssueLines.Add($line) }

    Write-Log -Level DETAIL -Message ('ISSUE {0} [{1}/{2}] row={3} path={4} :: {5} {6}' -f $Severity, $Phase, $Category, $rowText, $ItemPath, $Message, $AttemptDetails)
}

function Open-RunOutputs {
    param([string]$BaseFolder)
    $s = $script:State
    $ts = $s.RunTimestamp
    [void][System.IO.Directory]::CreateDirectory($BaseFolder)
    if ($s.Mode -eq 'Diagnostic') {
        $folder = Join-Path $BaseFolder ('Diagnostic_' + $ts)
        [void][System.IO.Directory]::CreateDirectory($folder)
        $s.Paths.OutputFolder = $folder
        $s.Paths.LogTxt = Join-Path $folder 'Diagnostic_Log.txt'
        $s.Paths.IssueCsv = Join-Path $folder 'Diagnostic_Errors.csv'
        $s.Paths.SourcesCsv = Join-Path $folder 'Diagnostic_Sources.csv'
        $s.Paths.DiagReportTxt = Join-Path $folder 'Diagnostic_Report.txt'
        $s.Paths.DiagTestsCsv = Join-Path $folder 'Diagnostic_AccessTests.csv'
        $s.Paths.SummaryTxt = Join-Path $folder 'Diagnostic_Summary.txt'
        $s.Paths.DiagZip = Join-Path $BaseFolder ('Diagnostic_' + $ts + '.zip')
    }
    else {
        $s.Paths.OutputFolder = $BaseFolder
        $s.Paths.LogTxt = Join-Path $BaseFolder ('MetadataInventory_Log_' + $ts + '.txt')
        $s.Paths.IssueCsv = Join-Path $BaseFolder ('MetadataInventory_Errors_' + $ts + '.csv')
        $s.Paths.SourcesCsv = Join-Path $BaseFolder ('MetadataInventory_Sources_' + $ts + '.csv')
        $s.Paths.SummaryTxt = Join-Path $BaseFolder ('MetadataInventory_Summary_' + $ts + '.txt')
        $s.Paths.InventoryCsv = Join-Path $BaseFolder ('MetadataInventory_' + $ts + '.csv')
        $s.Paths.SupportZip = Join-Path $BaseFolder ('MetadataInventory_SendThis_' + $ts + '.zip')
        if ($s.Options.LocalizedExcelCopy) {
            $s.Paths.LocalizedCsv = Join-Path $BaseFolder ('MetadataInventory_' + $ts + '_LocalDecimal.csv')
        }
    }

    $s.LogWriter = New-Utf8Writer -Path $s.Paths.LogTxt -AutoFlush $true
    $s.IssueWriter = New-Utf8Writer -Path $s.Paths.IssueCsv -AutoFlush $true
    $s.IssueWriter.WriteLine((ConvertTo-CsvLine -Fields $script:IssueColumns))
    foreach ($pending in $s.PendingIssueLines) { $s.IssueWriter.WriteLine($pending) }
    $s.PendingIssueLines.Clear()

    if ($s.Mode -ne 'Diagnostic') {
        $s.InventoryWriter = New-Utf8Writer -Path $s.Paths.InventoryCsv
        $s.InventoryWriter.WriteLine((ConvertTo-CsvLine -Fields $script:InventoryColumns))
        if ($s.Paths.LocalizedCsv) {
            $s.LocalizedWriter = New-Utf8Writer -Path $s.Paths.LocalizedCsv
            $s.LocalizedWriter.WriteLine((ConvertTo-CsvLine -Fields $script:InventoryColumns))
        }
    }
}

function Close-RunOutputs {
    $s = $script:State
    if ($null -eq $s) { return }
    foreach ($name in @('InventoryWriter', 'LocalizedWriter', 'IssueWriter', 'LogWriter')) {
        $writer = $s[$name]
        if ($null -ne $writer) {
            try { $writer.Flush() } catch { }
            try { $writer.Dispose() } catch { }
            $s[$name] = $null
        }
    }
}

# ============================================================================
# Platform and file-system engine
# ============================================================================
function Test-IsWindowsPlatform {
    if ($PSVersionTable.PSVersion.Major -lt 6) { return $true }
    return [bool](Get-Variable -Name IsWindows -ValueOnly -ErrorAction SilentlyContinue)
}

function Test-IsElevated {
    if (-not (Test-IsWindowsPlatform)) { return $false }
    try {
        $identity = [System.Security.Principal.WindowsIdentity]::GetCurrent()
        $principal = New-Object System.Security.Principal.WindowsPrincipal($identity)
        return $principal.IsInRole([System.Security.Principal.WindowsBuiltInRole]::Administrator)
    }
    catch { return $false }
}

function Test-DotNetExtendedPathSupport {
    # Tells whether .NET in THIS process accepts \\?\ paths. Windows PowerShell 5.1 may run with
    # legacy .NET path handling, in which case [IO.Directory]::Exists('\\?\C:\Windows') is False.
    if (-not (Test-IsWindowsPlatform)) { return $null }
    try {
        $root = $env:SystemRoot
        if (-not $root) { return $null }
        if (-not [System.IO.Directory]::Exists($root)) { return $null }
        return [System.IO.Directory]::Exists('\\?\' + $root)
    }
    catch { return $false }
}

function Initialize-FileSystemEngine {
    param([ValidateSet('Auto', 'Win32', 'DotNet', 'Mock')][string]$Requested = 'Auto')
    $s = $script:State
    $s.DotNetExtendedPathSupport = Test-DotNetExtendedPathSupport
    if ($Requested -eq 'Mock') {
        $s.Engine = 'Mock'
        $s.EngineDetail = 'Mock engine (automated tests only)'
        return
    }
    $win32Error = ''
    if ((Test-IsWindowsPlatform) -and $Requested -ne 'DotNet') {
        if (-not ('MetadataInventoryNative.Win32Fs' -as [type])) {
            try { Add-Type -TypeDefinition $script:NativeSource -Language CSharp -IgnoreWarnings -ErrorAction Stop }
            catch { $win32Error = $_.Exception.Message }
        }
        if ('MetadataInventoryNative.Win32Fs' -as [type]) {
            $s.Engine = 'Win32'
            $s.EngineDetail = 'Native Win32 (FindFirstFileExW / GetFileAttributesExW), read-only'
            return
        }
        if ($Requested -eq 'Win32') { throw ('The Win32 file-system engine could not be loaded: ' + $win32Error) }
    }
    $s.Engine = 'DotNet'
    $s.EngineDetail = '.NET System.IO fallback engine'
    if ($win32Error) { $s.EngineDetail += ' (Win32 engine unavailable: ' + $win32Error + ')' }
}

function Get-Win32Message {
    param([int]$Code)
    if ($Code -eq 0) { return '' }
    if ($script:Win32MessageCache.ContainsKey($Code)) { return $script:Win32MessageCache[$Code] }
    $text = 'Win32 error ' + $Code
    try { $text = (New-Object System.ComponentModel.Win32Exception($Code)).Message } catch { }
    $script:Win32MessageCache[$Code] = $text
    return $text
}

function Get-ErrorCategory {
    param([int]$Code)
    if ($Code -eq 0) { return '' }
    if ($script:Win32CategoryMap.ContainsKey($Code)) { return $script:Win32CategoryMap[$Code] }
    return 'Other'
}

function Get-InnermostException {
    param([System.Exception]$Exception)
    $e = $Exception
    while ($null -ne $e -and $e -is [System.Management.Automation.MethodInvocationException] -and $null -ne $e.InnerException) {
        $e = $e.InnerException
    }
    return $e
}

function Get-ExceptionWin32Code {
    param([System.Exception]$Exception)
    if ($null -eq $Exception) { return 0 }
    if ($Exception -is [System.UnauthorizedAccessException]) { return 5 }
    if ($Exception -is [System.IO.DirectoryNotFoundException]) { return 3 }
    if ($Exception -is [System.IO.FileNotFoundException]) { return 2 }
    if ($Exception -is [System.IO.PathTooLongException]) { return 206 }
    if ($Exception -is [System.ArgumentException]) { return 123 }
    if ($Exception -is [System.NotSupportedException]) { return 123 }
    $hr = [long]$Exception.HResult
    if (($hr -band 0xFFFF0000L) -eq 0x80070000L) { return [int]($hr -band 0xFFFFL) }
    return 0
}

function New-FsEntryObject {
    param(
        [string]$Name = '',
        [long]$Attributes = 0,
        [long]$Size = 0,
        [long]$CreationFileTime = 0,
        [long]$LastAccessFileTime = 0,
        [long]$LastWriteFileTime = 0,
        [long]$ReparseTag = 0
    )
    $isReparse = (($Attributes -band 0x400) -ne 0)
    return [pscustomobject]@{
        Name               = $Name
        Attributes         = $Attributes
        Size               = $Size
        CreationFileTime   = $CreationFileTime
        LastAccessFileTime = $LastAccessFileTime
        LastWriteFileTime  = $LastWriteFileTime
        ReparseTag         = $ReparseTag
        IsDirectory        = (($Attributes -band 0x10) -ne 0)
        IsReparsePoint     = $isReparse
        IsNameSurrogate    = ($isReparse -and (($ReparseTag -band 0x20000000) -ne 0))
    }
}

function New-FsResult {
    param(
        [bool]$Ok,
        [AllowNull()][object]$Entry = $null,
        [AllowNull()][object]$Entries = $null,
        [int]$Code = 0,
        [AllowEmptyString()][string]$Message = '',
        [AllowEmptyString()][string]$ExceptionType = '',
        [bool]$Partial = $false,
        [bool]$HasEntries = $false
    )
    $category = ''
    if (-not $Ok) {
        $category = Get-ErrorCategory -Code $Code
        if (-not $category) { $category = 'Other' }
        if (-not $Message) { $Message = Get-Win32Message -Code $Code }
    }
    return [pscustomobject]@{
        Ok            = $Ok
        Entry         = $Entry
        Entries       = $Entries
        Code          = $Code
        Category      = $category
        Message       = $Message
        ExceptionType = $ExceptionType
        Partial       = $Partial
        HasEntries    = $HasEntries
    }
}

function ConvertTo-FileTimeSafe {
    param([DateTime]$Value)
    try {
        if ($Value.Year -lt 1601) { return [long]0 }
        return $Value.ToFileTimeUtc()
    }
    catch { return [long]0 }
}

function ConvertFrom-FileSystemInfo {
    param([System.IO.FileSystemInfo]$Info, [string]$NameOverride = '')
    $attributes = [long][int]$Info.Attributes
    $isDirectory = (($attributes -band 0x10) -ne 0)
    $size = [long]0
    if (-not $isDirectory -and $Info -is [System.IO.FileInfo]) { $size = [long]$Info.Length }
    $name = $Info.Name
    if ($NameOverride) { $name = $NameOverride }
    return New-FsEntryObject -Name $name -Attributes $attributes -Size $size `
        -CreationFileTime (ConvertTo-FileTimeSafe $Info.CreationTimeUtc) `
        -LastAccessFileTime (ConvertTo-FileTimeSafe $Info.LastAccessTimeUtc) `
        -LastWriteFileTime (ConvertTo-FileTimeSafe $Info.LastWriteTimeUtc)
}

function New-FsExceptionResult {
    param([System.Exception]$Exception, [AllowNull()][object]$Entries = $null)
    $inner = Get-InnermostException $Exception
    $code = Get-ExceptionWin32Code $inner
    $partial = ($null -ne $Entries -and $Entries.Count -gt 0)
    return New-FsResult -Ok $false -Code $code -Message $inner.Message -ExceptionType $inner.GetType().FullName -Entries $Entries -Partial $partial
}

function Get-FsEntry {
    param([string]$Path)
    switch ($script:State.Engine) {
        'Win32' {
            $code = 0
            $entry = [MetadataInventoryNative.Win32Fs]::GetEntry($Path, [ref]$code)
            if ($null -ne $entry) { return (New-FsResult -Ok $true -Entry $entry) }
            return (New-FsResult -Ok $false -Code $code)
        }
        'DotNet' {
            try {
                $attributes = [System.IO.File]::GetAttributes($Path)
                if (([int]$attributes -band 0x10) -ne 0) { $info = New-Object System.IO.DirectoryInfo($Path) }
                else { $info = New-Object System.IO.FileInfo($Path) }
                return (New-FsResult -Ok $true -Entry (ConvertFrom-FileSystemInfo -Info $info))
            }
            catch { return (New-FsExceptionResult -Exception $_.Exception) }
        }
        'Mock' { return (Get-FsEntryMock -Path $Path) }
        default { throw 'The file-system engine has not been initialized.' }
    }
}

function Get-FsChildren {
    param([string]$Path)
    switch ($script:State.Engine) {
        'Win32' {
            $result = [MetadataInventoryNative.Win32Fs]::ListDirectory($Path)
            if ($result.ErrorCode -eq 0) { return (New-FsResult -Ok $true -Entries $result.Entries) }
            return (New-FsResult -Ok $false -Code $result.ErrorCode -Entries $result.Entries -Partial $result.Partial)
        }
        'DotNet' {
            $list = New-Object 'System.Collections.Generic.List[object]'
            try {
                $directory = New-Object System.IO.DirectoryInfo($Path)
                foreach ($info in $directory.EnumerateFileSystemInfos()) { $list.Add((ConvertFrom-FileSystemInfo -Info $info)) }
                return (New-FsResult -Ok $true -Entries $list)
            }
            catch { return (New-FsExceptionResult -Exception $_.Exception -Entries $list) }
        }
        'Mock' { return (Get-FsChildrenMock -Path $Path) }
        default { throw 'The file-system engine has not been initialized.' }
    }
}

function Test-FsListable {
    param([string]$Path)
    switch ($script:State.Engine) {
        'Win32' {
            $code = [MetadataInventoryNative.Win32Fs]::ProbeDirectory($Path)
            if ($code -eq 0) { return (New-FsResult -Ok $true -HasEntries $true) }
            if ($code -eq 2 -or $code -eq 18) { return (New-FsResult -Ok $true -HasEntries $false) }
            return (New-FsResult -Ok $false -Code $code)
        }
        'DotNet' {
            try {
                $directory = New-Object System.IO.DirectoryInfo($Path)
                $enumerator = $directory.EnumerateFileSystemInfos().GetEnumerator()
                $has = $enumerator.MoveNext()
                try { $enumerator.Dispose() } catch { }
                return (New-FsResult -Ok $true -HasEntries $has)
            }
            catch { return (New-FsExceptionResult -Exception $_.Exception) }
        }
        'Mock' { return (Test-FsListableMock -Path $Path) }
        default { throw 'The file-system engine has not been initialized.' }
    }
}

# ============================================================================
# Path handling (pure string operations: no [IO.Path] calls, so long paths are safe on PS 5.1)
# ============================================================================
function ConvertTo-NormalizedSourcePath {
    param([AllowNull()][object]$Value)
    $r = [ordered]@{ Original = ''; Normalized = ''; Kind = 'Empty'; IsValid = $false; Problem = ''; DriveLetter = '' }
    if ($null -eq $Value) { return [pscustomobject]$r }
    $text = [string]$Value
    $r.Original = $text
    $t = $text.Trim()
    if ($t.Length -ge 2 -and $t[0] -eq '"' -and $t[$t.Length - 1] -eq '"') { $t = $t.Substring(1, $t.Length - 2).Trim() }
    if ($t.Length -eq 0) { return [pscustomobject]$r }

    $r.Kind = 'Invalid'
    if ($t -match '[\x00-\x1F]') {
        $r.Problem = 'The path contains control characters (for example a line break inside the Excel cell).'
        return [pscustomobject]$r
    }
    $t = $t.Replace('/', '\')

    $kind = ''
    $body = ''
    if ($t.StartsWith('\\?\UNC\', $script:OrdinalIgnoreCase) -or $t.StartsWith('\\.\UNC\', $script:OrdinalIgnoreCase)) {
        $kind = 'UNC'; $body = $t.Substring(8)
    }
    elseif ($t.StartsWith('\\?\') -or $t.StartsWith('\\.\')) {
        $rest = $t.Substring(4)
        if ($rest -match '^[A-Za-z]:(\\|$)') { $kind = 'Drive'; $body = $rest }
        else {
            $r.Problem = 'Unsupported device path. Use X:\folder or \\server\share\folder.'
            return [pscustomobject]$r
        }
    }
    elseif ($t.StartsWith('\\')) { $kind = 'UNC'; $body = $t.Substring(2) }
    elseif ($t -match '^[A-Za-z]:') { $kind = 'Drive'; $body = $t }
    else {
        $r.Kind = 'Relative'
        $r.Problem = 'Not an absolute path. Expected X:\folder or \\server\share\folder.'
        return [pscustomobject]$r
    }

    $prefix = ''
    $minimum = 0
    $letter = ''
    if ($kind -eq 'Drive') {
        $letter = $body.Substring(0, 1).ToUpperInvariant()
        $rest = $body.Substring(2)
        if ($rest.Length -gt 0 -and $rest[0] -ne '\') {
            $r.Problem = "Drive-relative path ('X:folder'): a backslash is required after the drive letter."
            return [pscustomobject]$r
        }
        $prefix = $letter + ':\'
        $segments = $rest.Split([char[]]@('\'), [System.StringSplitOptions]::RemoveEmptyEntries)
    }
    else {
        $prefix = '\\'
        $minimum = 2
        $segments = $body.Split([char[]]@('\'), [System.StringSplitOptions]::RemoveEmptyEntries)
    }

    $out = New-Object 'System.Collections.Generic.List[string]'
    foreach ($segment in $segments) {
        if ($segment -eq '.') { continue }
        if ($segment -eq '..') {
            if ($out.Count -le $minimum) {
                $r.Problem = "The path uses '..' to go above its root."
                return [pscustomobject]$r
            }
            $out.RemoveAt($out.Count - 1)
            continue
        }
        if ($segment.IndexOfAny($script:InvalidSegmentChars) -ge 0) {
            $r.Problem = "The path segment '" + $segment + "' contains an invalid character (< > : "" | ? *)."
            return [pscustomobject]$r
        }
        $out.Add($segment)
    }
    if ($kind -eq 'UNC' -and $out.Count -lt 2) {
        $r.Problem = 'A UNC path must contain at least \\server\share.'
        return [pscustomobject]$r
    }
    $r.Normalized = $prefix + [string]::Join('\', $out)
    $r.Kind = $kind
    $r.IsValid = $true
    $r.DriveLetter = $letter
    return [pscustomobject]$r
}

function ConvertTo-ExtendedPath {
    param([string]$Path)
    if ($Path.StartsWith('\\?\')) { return $Path }
    if ($Path.StartsWith('\\')) { return '\\?\UNC\' + $Path.Substring(2) }
    if ($Path -match '^[A-Za-z]:\\') { return '\\?\' + $Path }
    return $Path
}

function ConvertTo-PlainPath {
    param([string]$Path)
    if ($Path.StartsWith('\\?\UNC\', $script:OrdinalIgnoreCase)) { return '\\' + $Path.Substring(8) }
    if ($Path.StartsWith('\\?\')) { return $Path.Substring(4) }
    return $Path
}

function Get-PathRootLength {
    # Length of the non-removable root: "X:\" (3), "\\?\X:\" (7), "\\server\share", "\\?\UNC\server\share".
    param([string]$Path)
    $start = -1
    if ($Path.StartsWith('\\?\UNC\', $script:OrdinalIgnoreCase)) { $start = 8 }
    elseif ($Path.StartsWith('\\?\')) {
        if ($Path.Length -ge 7) { return 7 }
        return $Path.Length
    }
    elseif ($Path.StartsWith('\\')) { $start = 2 }
    elseif ($Path -match '^[A-Za-z]:\\') { return 3 }
    else { return 0 }
    $serverEnd = $Path.IndexOf('\', $start)
    if ($serverEnd -lt 0) { return $Path.Length }
    $shareEnd = $Path.IndexOf('\', $serverEnd + 1)
    if ($shareEnd -lt 0) { return $Path.Length }
    return $shareEnd
}

function Test-IsShareRoot {
    param([string]$Path)
    if (-not $Path.StartsWith('\\')) { return $false }
    if ($Path.StartsWith('\\?\') -and -not $Path.StartsWith('\\?\UNC\', $script:OrdinalIgnoreCase)) { return $false }
    return ((Get-PathRootLength $Path) -eq $Path.TrimEnd('\').Length)
}

function Get-PathAncestors {
    # Returns the ancestors of a path, nearest first, down to and including the root.
    param([string]$Path)
    $result = New-Object 'System.Collections.Generic.List[string]'
    $rootLength = Get-PathRootLength $Path
    $current = $Path
    while ($current.Length -gt $rootLength) {
        $index = $current.LastIndexOf('\')
        if ($index -ge $rootLength) { $parent = $current.Substring(0, $index) }
        else { $parent = $current.Substring(0, $rootLength) }
        if ($parent.Length -eq 0 -or $parent -eq $current) { break }
        $result.Add($parent)
        $current = $parent
    }
    return , $result
}

function Join-FsPath {
    param([string]$Parent, [AllowEmptyString()][string]$Child)
    if (-not $Child) { return $Parent }
    if ($Parent.EndsWith('\')) { return $Parent + $Child }
    return $Parent + '\' + $Child
}

function Get-ParentLogicalPath {
    param([string]$Path)
    $ancestors = Get-PathAncestors $Path
    if ($ancestors.Count -eq 0) { return '' }
    return $ancestors[0]
}

function Get-LeafName {
    param([string]$Path)
    if ($Path -match '^[A-Za-z]:\\$') { return $Path }
    $trimmed = $Path.TrimEnd('\')
    $index = $trimmed.LastIndexOf('\')
    if ($index -lt 0) { return $trimmed }
    return $trimmed.Substring($index + 1)
}

function Split-NameExtension {
    # Same semantics as [IO.Path]::GetExtension / GetFileNameWithoutExtension, without the
    # path validation that throws on long paths in Windows PowerShell 5.1.
    param([string]$Name)
    $index = $Name.LastIndexOf('.')
    if ($index -lt 0) { return @($Name, '') }
    if ($index -eq $Name.Length - 1) { return @($Name.Substring(0, $index), '') }
    return @($Name.Substring(0, $index), $Name.Substring($index))
}

function Split-UncServer {
    param([string]$Path)
    $body = $Path.Substring(2)
    $index = $body.IndexOf('\')
    if ($index -lt 0) { return [pscustomobject]@{ Server = $body; Rest = '' } }
    return [pscustomobject]@{ Server = $body.Substring(0, $index); Rest = $body.Substring($index) }
}

function Get-UncSegmentCount {
    param([string]$Path)
    if (-not $Path.StartsWith('\\')) { return 0 }
    return $Path.Substring(2).Split([char[]]@('\'), [System.StringSplitOptions]::RemoveEmptyEntries).Count
}

function Test-SameUncPath {
    # Equal ignoring case, or equal after reducing server names to their short (NetBIOS) form.
    param([string]$A, [string]$B)
    if ([string]::Equals($A, $B, $script:OrdinalIgnoreCase)) { return $true }
    if (-not ($A.StartsWith('\\') -and $B.StartsWith('\\'))) { return $false }
    $x = Split-UncServer $A
    $y = Split-UncServer $B
    if (-not [string]::Equals($x.Rest, $y.Rest, $script:OrdinalIgnoreCase)) { return $false }
    return [string]::Equals($x.Server.Split('.')[0], $y.Server.Split('.')[0], $script:OrdinalIgnoreCase)
}

function Test-IsOneDriveSystemItemName {
    param([string]$Name)
    if ($Name.Length -ne 37 -or $Name[0] -ne '.') { return $false }
    return ($Name -match '^\.[0-9A-Fa-f]{8}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{12}$')
}

# ============================================================================
# Mapped drives
# ============================================================================
function Get-RegistryValue {
    param([string]$Path, [string]$Name)
    try {
        $item = Get-ItemProperty -LiteralPath $Path -Name $Name -ErrorAction Stop
        return [string]$item.$Name
    }
    catch { return '' }
}

function Get-DriveMappingInfo {
    param([string]$Letter)
    $s = $script:State
    $L = $Letter.Substring(0, 1).ToUpperInvariant()
    if ($s.DriveCache.ContainsKey($L)) { return $s.DriveCache[$L] }

    $info = [ordered]@{
        Letter             = $L
        DriveType          = 'Unknown'
        IsAvailable        = $false
        WNetRemoteName     = ''
        WNetStatus         = ''
        PSDriveRoot        = ''
        RegistryRemotePath = ''
        ResolvedUnc        = ''
        ResolvedFrom       = ''
    }
    if ($s.Engine -eq 'Mock') {
        $mock = Get-DriveMappingInfoMock -Letter $L
        foreach ($key in @($mock.Keys)) { $info[$key] = $mock[$key] }
    }
    else {
        try {
            $drive = New-Object System.IO.DriveInfo($L)
            $info.DriveType = [string]$drive.DriveType
        }
        catch { $info.DriveType = 'Error: ' + $_.Exception.Message }
        $info.IsAvailable = ($info.DriveType -ne 'NoRootDirectory' -and $info.DriveType -ne 'Unknown' -and -not $info.DriveType.StartsWith('Error'))

        if ($s.Engine -eq 'Win32') {
            $code = 0
            $remote = [MetadataInventoryNative.Win32Fs]::GetDriveRemoteName($L + ':', [ref]$code)
            if ($remote) { $info.WNetRemoteName = $remote }
            switch ($code) {
                0 { $info.WNetStatus = 'Connected' }
                1201 { $info.WNetStatus = 'Remembered but currently disconnected (1201)' }
                2250 { $info.WNetStatus = 'Not a network drive in this logon session (2250)' }
                default { $info.WNetStatus = ('Error {0}: {1}' -f $code, (Get-Win32Message $code)) }
            }
        }
        try {
            $psDrive = Get-PSDrive -Name $L -PSProvider FileSystem -ErrorAction Stop
            if ($psDrive.DisplayRoot) { $info.PSDriveRoot = [string]$psDrive.DisplayRoot }
        }
        catch { }
        $info.RegistryRemotePath = Get-RegistryValue -Path ('HKCU:\Network\' + $L) -Name 'RemotePath'
    }

    foreach ($pair in @(@('WNetGetConnection', $info.WNetRemoteName), @('Get-PSDrive', $info.PSDriveRoot), @('HKCU\Network registry', $info.RegistryRemotePath))) {
        $candidate = [string]$pair[1]
        if ($candidate -and $candidate.StartsWith('\\')) {
            $normalized = ConvertTo-NormalizedSourcePath $candidate
            if ($normalized.IsValid -and $normalized.Kind -eq 'UNC') {
                $info.ResolvedUnc = $normalized.Normalized
                $info.ResolvedFrom = [string]$pair[0]
                break
            }
        }
    }
    $result = [pscustomobject]$info
    $s.DriveCache[$L] = $result
    return $result
}

# ============================================================================
# Excel workbook
# ============================================================================
function ConvertTo-NormalizedHeader {
    param([AllowNull()][object]$Text)
    if ($null -eq $Text) { return '' }
    return (([string]$Text) -replace '\s+', ' ').Trim().ToLowerInvariant()
}

function Get-CellText {
    param([object]$Sheet, [int]$Row, [int]$Column)
    if ($Column -le 0) { return '' }
    $value = $Sheet.GetValue($Row, $Column)
    if ($null -eq $value) { return '' }
    return [string]$value
}

function ConvertTo-NullableNumber {
    param([AllowNull()][object]$Value)
    if ($null -eq $Value) { return $null }
    if ($Value -is [double] -or $Value -is [int] -or $Value -is [long] -or $Value -is [decimal]) { return [double]$Value }
    $parsed = 0.0
    if ([double]::TryParse([string]$Value, [System.Globalization.NumberStyles]::Any, $script:Invariant, [ref]$parsed)) { return $parsed }
    return $null
}

function Import-ExcelLibrary {
    if ('OfficeOpenXml.ExcelPackage' -as [type]) { return 'EPPlus already loaded' }
    $moduleFolder = Join-Path $script:ScriptBase 'Modules\ImportExcel\7.8.10'
    $bundled = Join-Path $moduleFolder 'ImportExcel.psd1'
    if (Test-Path -LiteralPath $bundled) {
        # Files extracted from a downloaded ZIP carry a "blocked" mark that can stop EPPlus.dll from
        # loading. This only touches the package's own module files, never the source documents.
        try { Get-ChildItem -LiteralPath $moduleFolder -Recurse -File -ErrorAction Stop | Unblock-File -ErrorAction SilentlyContinue } catch { }
        Import-Module -Name $bundled -Force -DisableNameChecking -ErrorAction Stop
        return ('Bundled ImportExcel 7.8.10 (' + $bundled + ')')
    }
    $available = @(Get-Module -ListAvailable -Name ImportExcel | Sort-Object -Property Version -Descending)
    if ($available.Count -gt 0) {
        Import-Module -Name $available[0].Path -Force -DisableNameChecking -ErrorAction Stop
        return ('Installed ImportExcel ' + $available[0].Version + ' (' + $available[0].Path + ')')
    }
    throw ('The ImportExcel module was not found. Expected: ' + $bundled + '. Extract the complete ZIP package and run the BAT file from the extracted folder.')
}

function Read-MigrationWorkbook {
    param([string]$Path, [string]$SheetName = 'MetaData')
    $stream = $null
    $package = $null
    try {
        $stream = New-Object System.IO.FileStream($Path, [System.IO.FileMode]::Open, [System.IO.FileAccess]::Read, [System.IO.FileShare]::ReadWrite)
        $package = New-Object OfficeOpenXml.ExcelPackage
        $package.Load($stream)
        $sheet = $null
        $names = New-Object 'System.Collections.Generic.List[string]'
        foreach ($ws in $package.Workbook.Worksheets) {
            $names.Add($ws.Name)
            if ($null -eq $sheet -and $ws.Name.Trim() -eq $SheetName.Trim()) { $sheet = $ws }
        }
        if ($null -eq $sheet) {
            throw ("Worksheet '{0}' was not found in the workbook. Available worksheets: {1}" -f $SheetName, ([string]::Join(', ', $names)))
        }
        $rows = New-Object 'System.Collections.Generic.List[object]'
        $dimension = $sheet.Dimension
        if ($null -eq $dimension) {
            return [pscustomobject]@{ SheetName = $sheet.Name; Rows = $rows; DataRowsRead = 0; BlankRows = 0; Headers = @(); ColumnMap = @{} }
        }
        $lastRow = $dimension.End.Row
        $lastColumn = $dimension.End.Column

        $headerMap = @{}
        $headers = New-Object 'System.Collections.Generic.List[string]'
        for ($c = 1; $c -le $lastColumn; $c++) {
            $raw = $sheet.GetValue(1, $c)
            if ($null -eq $raw) { continue }
            $headers.Add([string]$raw)
            $key = ConvertTo-NormalizedHeader $raw
            if ($key -and -not $headerMap.ContainsKey($key)) { $headerMap[$key] = $c }
        }
        $map = @{}
        foreach ($name in $script:ExcelColumnNames.Keys) {
            $key = ConvertTo-NormalizedHeader $script:ExcelColumnNames[$name]
            if ($headerMap.ContainsKey($key)) { $map[$name] = [int]$headerMap[$key] } else { $map[$name] = 0 }
        }
        if ($map.ToBeUploaded -eq 0) {
            throw ("Required column '{0}' was not found in worksheet '{1}'. Columns found: {2}" -f $script:ExcelColumnNames.ToBeUploaded, $sheet.Name, ([string]::Join(' | ', $headers)))
        }
        if ($map.SourceFolder -eq 0 -and $map.UncSourceFolder -eq 0 -and $map.UncFolder -eq 0) {
            throw ("None of the source path columns ('Source Folder', 'UNC Source Folder', 'UNC Folder') was found in worksheet '{0}'. Columns found: {1}" -f $sheet.Name, ([string]::Join(' | ', $headers)))
        }

        $blank = 0
        for ($r = 2; $r -le $lastRow; $r++) {
            $yes = Get-CellText $sheet $r $map.ToBeUploaded
            $src = Get-CellText $sheet $r $map.SourceFolder
            $unc = Get-CellText $sheet $r $map.UncSourceFolder
            $uncFolder = Get-CellText $sheet $r $map.UncFolder
            if (-not $yes.Trim() -and -not $src.Trim() -and -not $unc.Trim() -and -not $uncFolder.Trim()) { $blank++; continue }
            $origin = $null
            if ($map.OriginFiles -gt 0) { $origin = ConvertTo-NullableNumber ($sheet.GetValue($r, $map.OriginFiles)) }
            $rows.Add([pscustomobject]@{
                    ExcelRow        = $r
                    ToBeUploaded    = $yes
                    SourceFolder    = $src
                    UncSourceFolder = $unc
                    UncFolder       = $uncFolder
                    OriginFiles     = $origin
                })
        }
        return [pscustomobject]@{
            SheetName    = $sheet.Name
            Rows         = $rows
            DataRowsRead = [Math]::Max(0, $lastRow - 1)
            BlankRows    = $blank
            Headers      = $headers.ToArray()
            ColumnMap    = $map
        }
    }
    finally {
        if ($null -ne $package) { try { $package.Dispose() } catch { } }
        if ($null -ne $stream) { try { $stream.Dispose() } catch { } }
    }
}

function Select-ExcelFile {
    $dialogScript = {
        Add-Type -AssemblyName System.Windows.Forms
        $owner = New-Object System.Windows.Forms.Form
        $owner.TopMost = $true
        $owner.ShowInTaskbar = $false
        $dialog = New-Object System.Windows.Forms.OpenFileDialog
        $dialog.Filter = 'Excel workbooks (*.xlsx;*.xlsm)|*.xlsx;*.xlsm|All files (*.*)|*.*'
        $dialog.Title = 'Select the migration Excel workbook'
        $dialog.Multiselect = $false
        $dialog.CheckFileExists = $true
        $dialog.RestoreDirectory = $true
        try {
            if ($dialog.ShowDialog($owner) -eq [System.Windows.Forms.DialogResult]::OK) { $dialog.FileName } else { '' }
        }
        finally {
            $dialog.Dispose()
            $owner.Dispose()
        }
    }
    if ([System.Threading.Thread]::CurrentThread.GetApartmentState() -eq [System.Threading.ApartmentState]::STA) {
        return [string](@(& $dialogScript) | Select-Object -Last 1)
    }
    # File dialogs require a single-threaded apartment; run the dialog in an STA runspace.
    $runspace = [System.Management.Automation.Runspaces.RunspaceFactory]::CreateRunspace()
    $runspace.ApartmentState = [System.Threading.ApartmentState]::STA
    $runspace.Open()
    try {
        $ps = [System.Management.Automation.PowerShell]::Create()
        $ps.Runspace = $runspace
        [void]$ps.AddScript($dialogScript.ToString())
        $output = $ps.Invoke()
        $ps.Dispose()
        if ($output.Count -gt 0) { return [string]$output[$output.Count - 1] }
        return ''
    }
    finally { $runspace.Dispose() }
}

# ============================================================================
# Source candidates
# ============================================================================
function Get-FallbackEquivalence {
    param([object]$Primary, [object]$Fallback, [AllowNull()][object]$DriveInfo)
    if ([string]::Equals($Primary.Normalized, $Fallback.Normalized, $script:OrdinalIgnoreCase)) { return 'Identical' }
    if ($Primary.Kind -eq 'Drive' -and $Fallback.Kind -eq 'UNC') {
        $tail = $Primary.Normalized.Substring(2)
        if ($null -ne $DriveInfo -and $DriveInfo.ResolvedUnc) {
            $expected = Join-FsPath $DriveInfo.ResolvedUnc $tail.TrimStart('\')
            if (Test-SameUncPath $expected $Fallback.Normalized) { return 'VerifiedByDriveMapping' }
        }
        if ($tail.Length -gt 1 -and $Fallback.Normalized.EndsWith($tail, $script:OrdinalIgnoreCase)) {
            $prefix = $Fallback.Normalized.Substring(0, $Fallback.Normalized.Length - $tail.Length)
            if ((Get-UncSegmentCount $prefix) -ge 2) {
                if ($null -ne $DriveInfo -and $DriveInfo.ResolvedUnc -and -not (Test-SameUncPath $prefix $DriveInfo.ResolvedUnc)) {
                    return 'SameRelativePathDriveMappedElsewhere'
                }
                return 'SameRelativePath'
            }
        }
        return 'NotEquivalent'
    }
    if ($Primary.Kind -eq 'UNC' -and $Fallback.Kind -eq 'UNC') {
        if (Test-SameUncPath $Primary.Normalized $Fallback.Normalized) { return 'SameShareDifferentServerName' }
        return 'NotEquivalent'
    }
    if ($Primary.Kind -eq 'UNC' -and $Fallback.Kind -eq 'Drive') {
        $tail = $Fallback.Normalized.Substring(2)
        if ($tail.Length -gt 1 -and $Primary.Normalized.EndsWith($tail, $script:OrdinalIgnoreCase)) { return 'SameRelativePath' }
        return 'NotEquivalent'
    }
    return 'NotEquivalent'
}

function New-SourceCandidate {
    param([object]$Row)
    $s = $script:State
    $options = @(
        [pscustomobject]@{ Column = 'Source Folder'; Path = (ConvertTo-NormalizedSourcePath $Row.SourceFolder) },
        [pscustomobject]@{ Column = 'UNC Source Folder'; Path = (ConvertTo-NormalizedSourcePath $Row.UncSourceFolder) },
        [pscustomobject]@{ Column = 'UNC Folder'; Path = (ConvertTo-NormalizedSourcePath $Row.UncFolder) }
    )
    $candidate = [pscustomobject]@{
        ExcelRow            = [int]$Row.ExcelRow
        SourceFolder        = $options[0].Path.Original
        UncSourceFolder     = $options[1].Path.Original
        UncFolder           = $options[2].Path.Original
        SelectedColumn      = ''
        Primary             = $null
        LogicalPath         = ''
        CanonicalPath       = ''
        PathKind            = ''
        Fallbacks           = (New-Object 'System.Collections.Generic.List[object]')
        FallbackEquivalence = ''
        Status              = 'Pending'
        Detail              = ''
        Access              = $null
        CoveredByRow        = ''
        CoveredByPath       = ''
        DuplicateOfRow      = ''
        OriginFiles         = $Row.OriginFiles
        IsRecovery          = $false
        SkipRootItem        = $false
    }

    $valid = New-Object 'System.Collections.Generic.List[object]'
    $problems = New-Object 'System.Collections.Generic.List[string]'
    foreach ($option in $options) {
        if ($option.Path.IsValid) { $valid.Add($option) }
        elseif ($option.Path.Kind -ne 'Empty') { $problems.Add($option.Column + ': ' + $option.Path.Problem + ' [' + $option.Path.Original + ']') }
    }
    if ($valid.Count -eq 0) {
        if ($problems.Count -eq 0) {
            $candidate.Status = 'NoSourcePath'
            $candidate.Detail = 'The row is marked Yes, but Source Folder, UNC Source Folder and UNC Folder are all empty.'
        }
        else {
            $candidate.Status = 'InvalidPath'
            $candidate.Detail = [string]::Join(' | ', $problems)
        }
        return $candidate
    }

    $primaryOption = $valid[0]
    $primary = $primaryOption.Path
    $candidate.SelectedColumn = $primaryOption.Column
    $candidate.Primary = $primary
    $candidate.LogicalPath = $primary.Normalized
    $candidate.PathKind = $primary.Kind
    if ($problems.Count -gt 0) {
        $candidate.Detail = 'Ignored invalid value(s): ' + [string]::Join(' | ', $problems) + '. Using ' + $primaryOption.Column + '.'
    }

    $driveInfo = $null
    if ($primary.Kind -eq 'Drive') { $driveInfo = Get-DriveMappingInfo -Letter $primary.DriveLetter }

    $equivalenceText = New-Object 'System.Collections.Generic.List[string]'
    for ($i = 1; $i -lt $valid.Count; $i++) {
        $option = $valid[$i]
        $equivalence = Get-FallbackEquivalence -Primary $primary -Fallback $option.Path -DriveInfo $driveInfo
        $equivalenceText.Add($option.Column + '=' + $equivalence)
        if ($equivalence -eq 'Identical') { continue }
        $usable = ($script:EquivalentFallbackKinds -contains $equivalence) -or [bool]$s.Options.AllowNonEquivalentFallback
        $candidate.Fallbacks.Add([pscustomobject]@{ Column = $option.Column; Path = $option.Path; Equivalence = $equivalence; Usable = $usable })

        if ($primary.Kind -eq 'Drive' -and $option.Path.Kind -eq 'UNC' -and ($script:EquivalentFallbackKinds -contains $equivalence)) {
            $tail = $primary.Normalized.Substring(2)
            if ($tail.Length -gt 1) {
                $prefix = $option.Path.Normalized.Substring(0, $option.Path.Normalized.Length - $tail.Length)
                $letter = $primary.DriveLetter
                if (-not $s.ImpliedDriveMappings.ContainsKey($letter)) { $s.ImpliedDriveMappings[$letter] = @{} }
                $table = $s.ImpliedDriveMappings[$letter]
                if ($table.ContainsKey($prefix)) { $table[$prefix] = $table[$prefix] + 1 } else { $table[$prefix] = 1 }
            }
        }
    }
    $candidate.FallbackEquivalence = [string]::Join('; ', $equivalenceText)

    # Canonical path: the most location-independent spelling of the same folder, used only for
    # deduplication and overlap detection. FullPath in the inventory always stays LogicalPath.
    $canonical = $primary.Normalized
    if ($primary.Kind -eq 'Drive') {
        $equivalentUnc = $null
        foreach ($fallback in $candidate.Fallbacks) {
            if ($fallback.Path.Kind -eq 'UNC' -and ($script:EquivalentFallbackKinds -contains $fallback.Equivalence)) { $equivalentUnc = $fallback; break }
        }
        if ($null -ne $equivalentUnc) { $canonical = $equivalentUnc.Path.Normalized }
        elseif ($null -ne $driveInfo -and $driveInfo.ResolvedUnc) { $canonical = Join-FsPath $driveInfo.ResolvedUnc $primary.Normalized.Substring(3) }
    }
    $candidate.CanonicalPath = $canonical
    return $candidate
}

function Build-SourceCandidates {
    param([object]$Rows)
    $s = $script:State
    $c = $s.Counters
    $index = 0
    # Do not use @($Rows) here: on Windows PowerShell 5.1 the array subexpression applied to a
    # generic List throws "Argument types do not match".
    $total = 0
    if ($null -ne $Rows) { foreach ($counted in $Rows) { $total++ } }
    foreach ($row in $Rows) {
        $index++
        if (($index % 2000) -eq 0) {
            Write-Progress -Id 1 -Activity 'Preparing source list' -Status ('Excel row {0} of {1}' -f $index, $total) -PercentComplete ([int][Math]::Min(100, ($index * 100.0) / [Math]::Max(1, $total)))
        }
        $flag = ''
        if ($null -ne $row.ToBeUploaded) { $flag = ([string]$row.ToBeUploaded).Trim() }
        if ($flag -ne 'Yes') { continue }
        $c.YesRows++
        try { $candidate = New-SourceCandidate -Row $row }
        catch {
            # One unexpected row must never stop the inventory.
            $inner = Get-InnermostException $_.Exception
            $candidate = [pscustomobject]@{
                ExcelRow = [int]$row.ExcelRow; SourceFolder = [string]$row.SourceFolder; UncSourceFolder = [string]$row.UncSourceFolder; UncFolder = [string]$row.UncFolder
                SelectedColumn = ''; Primary = $null; LogicalPath = ''; CanonicalPath = ''; PathKind = ''; Fallbacks = (New-Object 'System.Collections.Generic.List[object]')
                FallbackEquivalence = ''; Status = 'InvalidPath'; Detail = ('Unexpected error while reading this row: ' + $inner.Message); Access = $null
                CoveredByRow = ''; CoveredByPath = ''; DuplicateOfRow = ''; OriginFiles = $null; IsRecovery = $false; SkipRootItem = $false
            }
        }
        $s.Candidates.Add($candidate)
        switch ($candidate.Status) {
            'NoSourcePath' {
                $c.RowsWithoutSourcePath++
                Add-RunIssue -Severity Warning -Phase 'Excel' -Category 'NoSourcePath' -ExcelRow $candidate.ExcelRow -Message 'No Source Folder / UNC fallback path found.'
            }
            'InvalidPath' {
                $c.RowsWithInvalidPath++
                Add-RunIssue -Severity Error -Phase 'Excel' -Category 'InvalidPath' -ExcelRow $candidate.ExcelRow -SourcePath $candidate.SourceFolder -Message ('Invalid source path: ' + $candidate.Detail)
            }
            default {
                $c.ValidCandidates++
                if ($candidate.Detail) {
                    Add-RunIssue -Severity Warning -Phase 'Excel' -Category 'InvalidPath' -ExcelRow $candidate.ExcelRow -SourcePath $candidate.LogicalPath -Message $candidate.Detail
                }
            }
        }
    }
    Write-Progress -Id 1 -Activity 'Preparing source list' -Completed

    foreach ($candidate in $s.Candidates) {
        if ($candidate.Status -ne 'Pending') { continue }
        if (-not $s.RowByCanonical.ContainsKey($candidate.CanonicalPath)) { $s.RowByCanonical[$candidate.CanonicalPath] = $candidate.ExcelRow }
    }
    $c.UniqueSourcePaths = $s.RowByCanonical.Count
    Write-DriveMappingWarnings
}

function Write-DriveMappingWarnings {
    $s = $script:State
    foreach ($letter in @($s.ImpliedDriveMappings.Keys)) {
        $info = Get-DriveMappingInfo -Letter $letter
        $implied = $s.ImpliedDriveMappings[$letter]
        $top = @($implied.Keys | Sort-Object -Property @{ Expression = { $implied[$_] } } -Descending)
        if ($top.Count -eq 0) { continue }
        $impliedText = [string]::Join(', ', @($top | ForEach-Object { $_ + ' (' + $implied[$_] + ' rows)' }))
        if ($info.ResolvedUnc -and -not (Test-SameUncPath $info.ResolvedUnc $top[0])) {
            Add-RunIssue -Severity Warning -Phase 'DriveMapping' -Category 'DriveMappingMismatch' -SourcePath ($letter + ':\') -Message ('Drive ' + $letter + ': on this computer maps to ' + $info.ResolvedUnc + ', but the Excel UNC columns imply ' + $impliedText + '. The UNC location from Excel is tried first for these rows.')
        }
        Write-Log -Level DETAIL -Message ('Drive ' + $letter + ': type=' + $info.DriveType + '; resolved=' + $info.ResolvedUnc + ' (' + $info.ResolvedFrom + '); Excel implies ' + $impliedText)
    }
}

# ============================================================================
# Access validation
# ============================================================================
function Get-AccessAttempts {
    param([object]$Candidate)
    $s = $script:State
    $primary = $Candidate.Primary
    $groups = New-Object 'System.Collections.Generic.List[object]'
    if ($primary.Kind -eq 'Drive') {
        $info = Get-DriveMappingInfo -Letter $primary.DriveLetter
        $skip = ''
        if (-not $info.IsAvailable) { $skip = 'Drive ' + $primary.DriveLetter + ': is not available in this PowerShell session (drive type: ' + $info.DriveType + ').' }
        $groups.Add([pscustomobject]@{ Basis = 'Original'; PlainPath = $primary.Normalized; SkipReason = $skip; SkipCategory = 'DriveNotMapped' })
        if ($info.ResolvedUnc) {
            $groups.Add([pscustomobject]@{ Basis = 'DriveMapping'; PlainPath = (Join-FsPath $info.ResolvedUnc $primary.Normalized.Substring(3)); SkipReason = ''; SkipCategory = '' })
        }
    }
    else {
        $groups.Add([pscustomobject]@{ Basis = 'Original'; PlainPath = $primary.Normalized; SkipReason = ''; SkipCategory = '' })
    }
    foreach ($fallback in $Candidate.Fallbacks) {
        if (-not $fallback.Usable) { continue }
        $skip = ''
        if ($fallback.Path.Kind -eq 'Drive') {
            $fbInfo = Get-DriveMappingInfo -Letter $fallback.Path.DriveLetter
            if (-not $fbInfo.IsAvailable) { $skip = 'Drive ' + $fallback.Path.DriveLetter + ': is not available in this PowerShell session.' }
        }
        $group = [pscustomobject]@{ Basis = $fallback.Column; PlainPath = $fallback.Path.Normalized; SkipReason = $skip; SkipCategory = 'DriveNotMapped' }
        if ($fallback.Equivalence -eq 'SameRelativePathDriveMappedElsewhere') { $groups.Insert(0, $group) } else { $groups.Add($group) }
    }

    $attempts = New-Object 'System.Collections.Generic.List[object]'
    $seen = New-Object 'System.Collections.Generic.HashSet[string]' ([System.StringComparer]::OrdinalIgnoreCase)
    foreach ($group in $groups) {
        foreach ($form in @('Extended', 'Plain')) {
            if ($form -eq 'Extended') { $path = ConvertTo-ExtendedPath $group.PlainPath } else { $path = $group.PlainPath }
            if (-not $seen.Add($path)) { continue }
            $skipReason = $group.SkipReason
            $skipCategory = $group.SkipCategory
            if (-not $skipReason -and $form -eq 'Extended' -and $s.Engine -eq 'DotNet' -and $s.DotNetExtendedPathSupport -eq $false) {
                $skipReason = 'Not attempted: the .NET runtime of this PowerShell session does not accept \\?\ paths.'
                $skipCategory = ''
            }
            $attempts.Add([pscustomobject]@{
                    Basis        = $group.Basis
                    Form         = $form
                    Method       = $group.Basis + '/' + $form
                    Path         = $path
                    SkipReason   = $skipReason
                    SkipCategory = $skipCategory
                })
        }
    }
    return , $attempts
}

function Test-AccessPath {
    # Validates one concrete access path: reads its attributes and, for folders, opens a listing.
    param([string]$Path)
    $entryResult = Get-FsEntry -Path $Path
    if (-not $entryResult.Ok -and (Test-IsShareRoot $Path)) {
        $retry = Get-FsEntry -Path ($Path.TrimEnd('\') + '\')
        if ($retry.Ok) { $entryResult = $retry }
    }
    if ($entryResult.Ok -and -not $entryResult.Entry.IsDirectory) {
        return [pscustomobject]@{ Ok = $true; Entry = $entryResult.Entry; Category = ''; Code = 0; Message = ''; ExceptionType = ''; Note = 'File' }
    }
    if ($entryResult.Ok) {
        $list = Test-FsListable -Path $Path
        if ($list.Ok) {
            return [pscustomobject]@{ Ok = $true; Entry = $entryResult.Entry; Category = ''; Code = 0; Message = ''; ExceptionType = ''; Note = 'Folder' }
        }
        return [pscustomobject]@{ Ok = $false; Entry = $null; Category = $list.Category; Code = $list.Code; Message = ('The folder exists but its contents cannot be listed: ' + $list.Message); ExceptionType = $list.ExceptionType; Note = '' }
    }
    # Attributes could not be read. Some share roots refuse attribute queries but allow listing.
    if ($entryResult.Code -eq 5 -or $entryResult.Code -eq 87 -or $entryResult.Code -eq 50) {
        $list = Test-FsListable -Path $Path
        if ($list.Ok -and $list.HasEntries) {
            $synthetic = New-FsEntryObject -Name (Get-LeafName (ConvertTo-PlainPath $Path)) -Attributes 0x10
            return [pscustomobject]@{ Ok = $true; Entry = $synthetic; Category = ''; Code = 0; Message = ''; ExceptionType = ''; Note = ('Folder (its own attributes could not be read: ' + $entryResult.Message + ')') }
        }
    }
    return [pscustomobject]@{ Ok = $false; Entry = $null; Category = $entryResult.Category; Code = $entryResult.Code; Message = $entryResult.Message; ExceptionType = $entryResult.ExceptionType; Note = '' }
}

function Find-InheritedFailure {
    param([string]$Path)
    $s = $script:State
    if ($s.FailureCacheNetwork.Count -gt 0) {
        $plain = ConvertTo-PlainPath $Path
        if ($s.FailureCacheNetwork.ContainsKey($plain)) { return $s.FailureCacheNetwork[$plain] }
        foreach ($ancestor in (Get-PathAncestors $plain)) {
            if ($s.FailureCacheNetwork.ContainsKey($ancestor)) { return $s.FailureCacheNetwork[$ancestor] }
        }
    }
    if ($s.FailureCacheExact.Count -gt 0) {
        if ($s.FailureCacheExact.ContainsKey($Path)) { return $s.FailureCacheExact[$Path] }
        foreach ($ancestor in (Get-PathAncestors $Path)) {
            if ($s.FailureCacheExact.ContainsKey($ancestor)) { return $s.FailureCacheExact[$ancestor] }
        }
    }
    return $null
}

function Register-AccessFailure {
    param([string]$Path, [string]$Category, [int]$Code, [int]$ExcelRow)
    $s = $script:State
    $record = [pscustomobject]@{ Path = $Path; Category = $Category; Code = $Code; ExcelRow = $ExcelRow }
    if ($script:NetworkCategories -contains $Category) {
        $key = ConvertTo-PlainPath $Path
        if (-not $s.FailureCacheNetwork.ContainsKey($key)) { $s.FailureCacheNetwork[$key] = $record }
    }
    elseif ($Category -eq 'NotFound') {
        if (-not $s.FailureCacheExact.ContainsKey($Path)) { $s.FailureCacheExact[$Path] = $record }
    }
}

function Get-AttemptServer {
    # Server that an access path depends on (UNC server, or the server behind a mapped drive).
    param([string]$Path)
    $plain = ConvertTo-PlainPath $Path
    if ($plain.StartsWith('\\')) { return (Split-UncServer $plain).Server }
    if ($plain -match '^([A-Za-z]):') {
        $info = Get-DriveMappingInfo -Letter $Matches[1]
        if ($info.ResolvedUnc) { return (Split-UncServer $info.ResolvedUnc).Server }
    }
    return ''
}

function Get-ServerStatus {
    # DNS and TCP 445 are checked once per server. A server is only marked "down" after an SMB
    # access to it has also failed with a network error (see Resolve-SourceAccess), so a DNS or
    # firewall quirk alone never causes a path to be skipped.
    param([string]$Server)
    $s = $script:State
    if ($s.ServerStatus.ContainsKey($Server)) { return $s.ServerStatus[$Server] }
    if ($null -ne $s.Options.HostCheck) { $check = & $s.Options.HostCheck $Server }
    else { $check = Resolve-HostDiagnostic -HostName $Server }
    $dns = [string]$check.Dns
    $dnsOk = ($dns.Length -gt 0 -and -not $dns.StartsWith('<error'))
    $status = [pscustomobject]@{ Server = $Server; Dns = $dns; Tcp445 = [string]$check.Tcp445; DnsOk = $dnsOk; Down = $false; Reason = '' }
    $s.ServerStatus[$Server] = $status
    Write-Log -Level DETAIL -Message ('SERVER ' + $Server + ': DNS=' + $status.Dns + ' | TCP445=' + $status.Tcp445)
    return $status
}

function Test-ServerChecksEnabled {
    $s = $script:State
    return ($s.Engine -ne 'Mock' -or $null -ne $s.Options.HostCheck)
}

function Format-AttemptSummary {
    param([object]$Records)
    $parts = New-Object 'System.Collections.Generic.List[string]'
    foreach ($r in $Records) {
        $text = '[' + $r.Method + '] ' + $r.Path + ' -> ' + $r.Result
        if ($r.Category) { $text += ' ' + $r.Category }
        if ($r.Code) { $text += ' (' + $r.Code + ')' }
        if ($r.Message) { $text += ': ' + $r.Message }
        if ($r.DurationMs -gt 0) { $text += ' [' + $r.DurationMs + ' ms]' }
        $parts.Add($text)
    }
    return [string]::Join(' || ', $parts)
}

function Select-MostRelevantFailure {
    param([object]$Records)
    $best = $null
    $bestRank = [int]::MaxValue
    foreach ($r in $Records) {
        if ($r.Result -eq 'OK' -or -not $r.Category) { continue }
        $rank = [Array]::IndexOf($script:CategoryPriority, [string]$r.Category)
        if ($rank -lt 0) { $rank = $script:CategoryPriority.Count }
        if ($rank -lt $bestRank) { $best = $r; $bestRank = $rank }
    }
    if ($null -eq $best) {
        return [pscustomobject]@{ Category = 'NotAttempted'; Code = 0; Message = $script:CategoryDescriptions.NotAttempted; ExceptionType = '' }
    }
    return $best
}

function Resolve-SourceAccess {
    param([object]$Candidate)
    $attempts = Get-AccessAttempts -Candidate $Candidate
    $records = New-Object 'System.Collections.Generic.List[object]'
    foreach ($attempt in $attempts) {
        $record = [pscustomobject]@{ Method = $attempt.Method; Path = $attempt.Path; Result = ''; Category = ''; Code = 0; Message = ''; ExceptionType = ''; DurationMs = 0 }
        if ($attempt.SkipReason) {
            $record.Result = 'Skipped'
            $record.Category = $attempt.SkipCategory
            $record.Message = $attempt.SkipReason
            $records.Add($record)
            continue
        }
        $inherited = Find-InheritedFailure -Path $attempt.Path
        if ($null -ne $inherited) {
            $record.Result = 'Skipped'
            $record.Category = $inherited.Category
            $record.Code = $inherited.Code
            $record.Message = ("Not attempted: '{0}' already failed with {1} (Excel row {2})." -f $inherited.Path, $inherited.Category, $inherited.ExcelRow)
            $records.Add($record)
            continue
        }
        $server = ''
        if (Test-ServerChecksEnabled) { $server = Get-AttemptServer -Path $attempt.Path }
        if ($server) {
            $serverStatus = Get-ServerStatus -Server $server
            if ($serverStatus.Down) {
                $record.Result = 'Skipped'
                $record.Category = 'ServerUnreachable'
                $record.Code = 53
                $record.Message = 'Not attempted: ' + $serverStatus.Reason
                $records.Add($record)
                continue
            }
        }
        $watch = [System.Diagnostics.Stopwatch]::StartNew()
        $test = Test-AccessPath -Path $attempt.Path
        $watch.Stop()
        $record.DurationMs = [long]$watch.ElapsedMilliseconds
        if ($test.Ok) {
            $record.Result = 'OK'
            $record.Message = $test.Note
            $records.Add($record)
            return [pscustomobject]@{
                Accessible     = $true
                AccessPath     = $attempt.Path
                Method         = $attempt.Method
                Entry          = $test.Entry
                IsDirectory    = [bool]$test.Entry.IsDirectory
                Category       = ''
                Code           = 0
                Message        = $test.Note
                ExceptionType  = ''
                Attempts       = $records
                AttemptSummary = (Format-AttemptSummary $records)
            }
        }
        $record.Result = 'Failed'
        $record.Category = $test.Category
        $record.Code = $test.Code
        $record.Message = $test.Message
        $record.ExceptionType = $test.ExceptionType
        $records.Add($record)
        Register-AccessFailure -Path $attempt.Path -Category $test.Category -Code $test.Code -ExcelRow $Candidate.ExcelRow
        if ($server -and ($test.Category -eq 'ServerUnreachable' -or $test.Category -eq 'NetworkError')) {
            $serverStatus = Get-ServerStatus -Server $server
            if (-not $serverStatus.Down -and (-not $serverStatus.DnsOk -or $serverStatus.Tcp445 -ne 'OPEN')) {
                $serverStatus.Down = $true
                $reason = 'server ' + $server
                if (-not $serverStatus.DnsOk) { $reason += ' cannot be resolved by DNS (' + $serverStatus.Dns + ')' }
                else { $reason += ' does not answer on TCP port 445 (' + $serverStatus.Tcp445 + ')' }
                $serverStatus.Reason = $reason + ' and SMB access failed with ' + $test.Category + ' (' + $test.Code + ').'
                Write-Log -Level WARN -Message ('  Server marked unreachable for this run: ' + $serverStatus.Reason)
            }
        }
    }
    $best = Select-MostRelevantFailure $records
    return [pscustomobject]@{
        Accessible     = $false
        AccessPath     = ''
        Method         = ''
        Entry          = $null
        IsDirectory    = $false
        Category       = [string]$best.Category
        Code           = [int]$best.Code
        Message        = [string]$best.Message
        ExceptionType  = [string]$best.ExceptionType
        Attempts       = $records
        AttemptSummary = (Format-AttemptSummary $records)
    }
}

# ============================================================================
# Planning: validate roots parent-first; only ACCESSIBLE roots cover their children.
# ============================================================================
function Invoke-SourcePlanning {
    param([System.Collections.Generic.List[object]]$Candidates, [switch]$Recovery)
    $s = $script:State
    $c = $s.Counters
    $pending = @($Candidates | Where-Object { $_.Status -eq 'Pending' } | Sort-Object -Property @{ Expression = { $_.CanonicalPath.Length } }, @{ Expression = { $_.ExcelRow } })
    $first = New-Object 'System.Collections.Generic.Dictionary[string,object]' ([System.StringComparer]::OrdinalIgnoreCase)
    $accessible = New-Object 'System.Collections.Generic.Dictionary[string,object]' ([System.StringComparer]::OrdinalIgnoreCase)
    $activity = 'Checking access to source paths'
    if ($Recovery) { $activity = 'Re-checking child roots below folders that could not be listed' }
    $index = 0
    foreach ($candidate in $pending) {
        $index++
        if ($s.ProgressWatch.ElapsedMilliseconds -ge 300) {
            $s.ProgressWatch.Restart()
            Write-Progress -Id 1 -Activity $activity -Status ('{0} of {1} | accessible roots: {2} | inaccessible: {3}' -f $index, $pending.Count, $c.AccessibleRoots, $c.InaccessibleRoots) -CurrentOperation $candidate.LogicalPath -PercentComplete ([int][Math]::Min(100, ($index * 100.0) / [Math]::Max(1, $pending.Count)))
        }
        if ($first.ContainsKey($candidate.CanonicalPath)) {
            $original = $first[$candidate.CanonicalPath]
            $candidate.Status = 'Duplicate'
            $candidate.DuplicateOfRow = [string]$original.ExcelRow
            $candidate.Detail = 'Same source location as Excel row ' + $original.ExcelRow + '.'
            $c.DuplicateRows++
            continue
        }
        $first[$candidate.CanonicalPath] = $candidate

        $cover = $null
        foreach ($ancestor in (Get-PathAncestors $candidate.CanonicalPath)) {
            if ($accessible.ContainsKey($ancestor)) { $cover = $accessible[$ancestor]; break }
        }
        if ($null -ne $cover) {
            $candidate.Status = 'Covered'
            $candidate.CoveredByRow = [string]$cover.ExcelRow
            $candidate.CoveredByPath = $cover.LogicalPath
            $candidate.Detail = 'Included in the recursive scan of Excel row ' + $cover.ExcelRow + '.'
            $c.CoveredRows++
            continue
        }

        $c.RootsEvaluated++
        try { $access = Resolve-SourceAccess -Candidate $candidate }
        catch {
            $inner = Get-InnermostException $_.Exception
            Write-Log -Level DETAIL -Message ('Access check exception for row ' + $candidate.ExcelRow + ': ' + $_.ScriptStackTrace)
            $access = [pscustomobject]@{
                Accessible = $false; AccessPath = ''; Method = ''; Entry = $null; IsDirectory = $false; Category = 'Other'; Code = 0
                Message = ('Unexpected error while checking access: ' + $inner.Message); ExceptionType = $inner.GetType().FullName
                Attempts = (New-Object 'System.Collections.Generic.List[object]'); AttemptSummary = ''
            }
        }
        $candidate.Access = $access
        if ($access.Accessible) {
            $candidate.Status = 'Root'
            if ($Recovery) {
                $candidate.Detail = 'Scanned separately because a parent folder could not be listed during the parent scan.'
                $c.RecoveredRoots++
            }
            $accessible[$candidate.CanonicalPath] = $candidate
            $s.Roots.Add($candidate)
            $c.AccessibleRoots++
            if ($s.ConsoleRootLines -lt 200) {
                $s.ConsoleRootLines++
                Write-Log -Level OK -Message ('  [OK]   Row {0}: {1}  (via {2})' -f $candidate.ExcelRow, $candidate.LogicalPath, $access.Method)
            }
            else { Write-Log -Level DETAIL -Message ('ROOT OK row {0}: {1} via {2}' -f $candidate.ExcelRow, $candidate.LogicalPath, $access.Method) }
        }
        else {
            $candidate.Status = 'Inaccessible'
            $description = ''
            if ($script:CategoryDescriptions.ContainsKey($access.Category)) { $description = $script:CategoryDescriptions[$access.Category] }
            $candidate.Detail = $access.Category + ': ' + $description
            $c.InaccessibleRoots++
            $prefix = 'Source path is not accessible'
            if ($access.Category -eq 'NotFound') { $prefix = 'Source path not found (checked with every available access method)' }
            Add-RunIssue -Severity Error -Phase 'SourceAccess' -Category $access.Category -ExcelRow $candidate.ExcelRow `
                -SourcePath $candidate.LogicalPath -ItemPath $candidate.LogicalPath `
                -Message ($prefix + ': ' + $candidate.LogicalPath + '. ' + $description + ' Last detail: ' + $access.Message) `
                -Win32Code $access.Code -ExceptionType $access.ExceptionType -AttemptDetails $access.AttemptSummary
            if ($s.ConsoleFailureLines -lt 50) {
                $s.ConsoleFailureLines++
                Write-Log -Level ERROR -Message ('  [FAIL] Row {0}: {1}  -> {2}' -f $candidate.ExcelRow, $candidate.LogicalPath, $access.Category)
            }
            elseif ($s.ConsoleFailureLines -eq 50) {
                $s.ConsoleFailureLines++
                Write-Log -Level WARN -Message '  (further inaccessible paths are only written to the log and the errors CSV)'
            }
        }
    }
    Write-Progress -Id 1 -Activity $activity -Completed
}

# ============================================================================
# Inventory output
# ============================================================================
function Format-FileTime {
    param([long]$FileTime, [switch]$Utc)
    if ($FileTime -le 0 -or $FileTime -gt 2650467743999999999) { return '' }
    $value = [DateTime]::FromFileTimeUtc($FileTime)
    if (-not $Utc) { $value = $value.ToLocalTime() }
    return $value.ToString('yyyy-MM-dd HH:mm:ss.fff', $script:Invariant)
}

function Format-FileAttributes {
    param([long]$Attributes)
    if ($script:AttributeCache.ContainsKey($Attributes)) { return $script:AttributeCache[$Attributes] }
    $names = New-Object 'System.Collections.Generic.List[string]'
    $known = [long]0
    foreach ($pair in $script:AttributeNames) {
        $bit = [long]$pair[0]
        $known = $known -bor $bit
        if (($Attributes -band $bit) -ne 0) { $names.Add([string]$pair[1]) }
    }
    $unknown = $Attributes -band (-bnot $known)
    if ($unknown -ne 0) { $names.Add('0x' + $unknown.ToString('X')) }
    $text = [string]::Join(', ', $names)
    $script:AttributeCache[$Attributes] = $text
    return $text
}

function Format-SizeMB {
    param([long]$Bytes, [System.IFormatProvider]$Culture = $script:Invariant)
    $mb = [Math]::Round($Bytes / 1048576.0, 3, [MidpointRounding]::AwayFromZero)
    return $mb.ToString('0.000', $Culture)
}

function Write-InventoryItem {
    param(
        [object]$Entry,
        [string]$Name,
        [string]$LogicalPath,
        [AllowEmptyString()][string]$ParentPath,
        [string]$SourceRoot,
        [string]$RelativePath,
        [int]$Depth,
        [int]$ExcelRow,
        [bool]$IsRoot
    )
    $s = $script:State
    $c = $s.Counters
    $inv = $script:Invariant
    $isDirectory = [bool]$Entry.IsDirectory
    $bytes = [long]0
    if ($isDirectory) {
        $itemType = 'Folder'; $baseName = $Name; $extension = ''; $sizeMb = ''
    }
    else {
        $itemType = 'File'
        $parts = Split-NameExtension $Name
        $baseName = $parts[0]; $extension = $parts[1]
        $bytes = [long]$Entry.Size
        $sizeMb = Format-SizeMB -Bytes $bytes
    }
    $rootText = 'False'
    if ($IsRoot) { $rootText = 'True' }
    $fields = @(
        $itemType, $Name, $baseName, $extension,
        $LogicalPath, $ParentPath, $SourceRoot, $RelativePath, $Depth.ToString($inv),
        $sizeMb,
        (Format-FileTime $Entry.CreationFileTime), (Format-FileTime $Entry.LastWriteFileTime), (Format-FileTime $Entry.LastAccessFileTime),
        (Format-FileTime $Entry.CreationFileTime -Utc), (Format-FileTime $Entry.LastWriteFileTime -Utc), (Format-FileTime $Entry.LastAccessFileTime -Utc),
        $LogicalPath.Length.ToString($inv), $Name.Length.ToString($inv), (Format-FileAttributes ([long]$Entry.Attributes)),
        $ExcelRow.ToString($inv), $rootText
    )
    $s.InventoryWriter.WriteLine((ConvertTo-CsvLine -Fields $fields))
    if ($null -ne $s.LocalizedWriter) {
        if (-not $isDirectory) { $fields[9] = Format-SizeMB -Bytes $bytes -Culture ([System.Globalization.CultureInfo]::CurrentCulture) }
        $s.LocalizedWriter.WriteLine((ConvertTo-CsvLine -Fields $fields))
    }
    $c.ItemsExported++
    if ($isDirectory) { $c.FoldersExported++ } else { $c.FilesExported++; $c.TotalBytes = $c.TotalBytes + $bytes }
}

function Test-ShouldDescend {
    param([object]$Entry)
    if (-not $Entry.IsDirectory) { return $false }
    if (-not $Entry.IsReparsePoint) { return $true }
    # Known tag: do not follow name surrogates (junctions, mount points, symbolic links); follow
    # everything else (OneDrive/cloud placeholders, DFS, deduplication, ...).
    if ([long]$Entry.ReparseTag -ne 0) { return (-not $Entry.IsNameSurrogate) }
    # Unknown tag: follow only folders that carry cloud-placeholder attributes.
    return (([long]$Entry.Attributes -band $script:CloudAttributeMask) -ne 0)
}

function Update-ScanProgress {
    param([switch]$Force)
    $s = $script:State
    if (-not $Force -and $s.ProgressWatch.ElapsedMilliseconds -lt 400) { return }
    $s.ProgressWatch.Restart()
    $c = $s.Counters
    $p = $s.Progress
    $percent = 0
    if ($p.SourceCount -gt 0) { $percent = [int][Math]::Floor((([Math]::Max(0, $p.SourceIndex - 1)) * 100.0) / $p.SourceCount) }
    $mb = ($c.TotalBytes / 1048576.0).ToString('N1', $script:Invariant)
    $status = 'Source {0} of {1} | items {2} (files {3}, folders {4}) | {5} MB | errors {6} | folders queued {7}' -f $p.SourceIndex, $p.SourceCount, $c.ItemsExported, $c.FilesExported, $c.FoldersExported, $mb, $s.ErrorCount, $p.QueueCount
    if ($c.ExcelEstimateFiles -gt 0) {
        $status += ' | ~' + ([Math]::Round(($c.FilesExported * 100.0) / $c.ExcelEstimateFiles, 0)).ToString($script:Invariant) + '% of the Excel "# Origin Files" estimate'
    }
    $current = [string]$p.CurrentPath
    if ($current.Length -gt 150) { $current = '...' + $current.Substring($current.Length - 147) }
    if (-not $current) { $current = ' ' }
    Write-Progress -Id 1 -Activity ('Metadata inventory - ' + $p.SourceLabel) -Status $status -CurrentOperation $current -PercentComplete ([Math]::Min(99, [Math]::Max(0, $percent)))
    if ($s.HeartbeatWatch.Elapsed.TotalSeconds -ge 30) {
        $s.HeartbeatWatch.Restart()
        Write-Log -Level INFO -Message ('  ... {0} | elapsed {1}' -f $status, (Format-Duration ((Get-Date) - $s.StartTime)))
        if ($null -ne $s.InventoryWriter) { $s.InventoryWriter.Flush() }
    }
}

function Invoke-RootScan {
    param([object]$Root)
    $s = $script:State
    $c = $s.Counters
    $access = $Root.Access
    $logicalRoot = $Root.LogicalPath
    $c.RootsScanned++

    if (-not $Root.SkipRootItem) {
        Write-InventoryItem -Entry $access.Entry -Name (Get-LeafName $logicalRoot) -LogicalPath $logicalRoot `
            -ParentPath (Get-ParentLogicalPath $logicalRoot) -SourceRoot $logicalRoot -RelativePath '.' -Depth 0 `
            -ExcelRow $Root.ExcelRow -IsRoot $true
    }
    if (-not $access.IsDirectory) { return }

    $stack = New-Object 'System.Collections.Generic.Stack[object]'
    $stack.Push([pscustomobject]@{ Access = $access.AccessPath; Logical = $logicalRoot; Canonical = $Root.CanonicalPath; Relative = '.'; Depth = 0; ExcelRow = $Root.ExcelRow })
    while ($stack.Count -gt 0) {
        $frame = $stack.Pop()
        $s.Progress.CurrentPath = $frame.Logical
        $s.Progress.QueueCount = $stack.Count
        $listing = Get-FsChildren -Path $frame.Access
        $c.DirectoriesEnumerated++
        if (-not $listing.Ok) {
            $c.DirectoryErrors++
            if (-not $s.FailedDirectories.ContainsKey($frame.Canonical)) {
                $s.FailedDirectories[$frame.Canonical] = [pscustomobject]@{ Logical = $frame.Logical; Category = $listing.Category; Code = $listing.Code; RootRow = $Root.ExcelRow }
            }
            $what = 'Folder contents could not be listed'
            if ($listing.Partial) { $what = 'Folder listing stopped before the end (the entries read so far were exported)' }
            Add-RunIssue -Severity Error -Phase 'Enumerate' -Category $listing.Category -ExcelRow $frame.ExcelRow -SourcePath $logicalRoot `
                -ItemPath $frame.Logical -AccessPath $frame.Access -AccessMethod $access.Method -Win32Code $listing.Code -ExceptionType $listing.ExceptionType `
                -Message ($what + ': ' + $listing.Message)
        }
        $childFrames = New-Object 'System.Collections.Generic.List[object]'
        if ($null -ne $listing.Entries) {
            foreach ($entry in $listing.Entries) {
                $name = [string]$entry.Name
                if (Test-IsOneDriveSystemItemName $name) { $c.SystemItemsSkipped++; continue }
                if ($frame.Logical.EndsWith('\')) { $childLogical = $frame.Logical + $name } else { $childLogical = $frame.Logical + '\' + $name }
                if ($frame.Access.EndsWith('\')) { $childAccess = $frame.Access + $name } else { $childAccess = $frame.Access + '\' + $name }
                if ($frame.Canonical.EndsWith('\')) { $childCanonical = $frame.Canonical + $name } else { $childCanonical = $frame.Canonical + '\' + $name }
                if ($frame.Relative -eq '.') { $childRelative = $name } else { $childRelative = $frame.Relative + '\' + $name }
                $childDepth = $frame.Depth + 1
                $row = $frame.ExcelRow
                $isRoot = $false
                $mappedRow = 0
                if ($s.RowByCanonical.TryGetValue($childCanonical, [ref]$mappedRow)) { $row = $mappedRow; $isRoot = $true }

                Write-InventoryItem -Entry $entry -Name $name -LogicalPath $childLogical -ParentPath $frame.Logical -SourceRoot $logicalRoot `
                    -RelativePath $childRelative -Depth $childDepth -ExcelRow $row -IsRoot $isRoot

                if ($entry.IsDirectory) {
                    if (Test-ShouldDescend $entry) {
                        $childFrames.Add([pscustomobject]@{ Access = $childAccess; Logical = $childLogical; Canonical = $childCanonical; Relative = $childRelative; Depth = $childDepth; ExcelRow = $row })
                    }
                    else {
                        $c.ReparsePointsNotFollowed++
                        Add-RunIssue -Severity Warning -Phase 'Enumerate' -Category 'ReparsePointNotFollowed' -ExcelRow $row -SourcePath $logicalRoot -ItemPath $childLogical `
                            -AccessPath $childAccess -Message ('Folder is a junction, mount point or symbolic link (reparse tag 0x{0}). It is listed but its contents are not scanned, to avoid loops and duplicates.' -f ([long]$entry.ReparseTag).ToString('X8'))
                    }
                }
                Update-ScanProgress
            }
        }
        for ($k = $childFrames.Count - 1; $k -ge 0; $k--) { $stack.Push($childFrames[$k]) }
        Update-ScanProgress
    }
}

function Invoke-RootScans {
    param([object[]]$Roots, [string]$Label)
    $s = $script:State
    $c = $s.Counters
    $ordered = @($Roots | Sort-Object -Property ExcelRow)
    $s.Progress.SourceCount = $ordered.Count
    $i = 0
    foreach ($root in $ordered) {
        $i++
        $s.Progress.SourceIndex = $i
        $s.Progress.SourceLabel = ('{0} {1} of {2} (Excel row {3})' -f $Label, $i, $ordered.Count, $root.ExcelRow)
        $beforeItems = $c.ItemsExported
        $beforeErrors = $s.ErrorCount
        $watch = [System.Diagnostics.Stopwatch]::StartNew()
        Write-Log -Level HEADER -Message ('[{0}/{1}] Row {2}: scanning {3}' -f $i, $ordered.Count, $root.ExcelRow, $root.LogicalPath)
        Write-Log -Level DETAIL -Message ('        access path: ' + $root.Access.AccessPath + ' (' + $root.Access.Method + ')')
        try {
            Invoke-RootScan -Root $root
        }
        catch {
            $inner = Get-InnermostException $_.Exception
            Add-RunIssue -Severity Error -Phase 'Scan' -Category 'Other' -ExcelRow $root.ExcelRow -SourcePath $root.LogicalPath -ItemPath $s.Progress.CurrentPath `
                -AccessPath $root.Access.AccessPath -AccessMethod $root.Access.Method -ExceptionType $inner.GetType().FullName `
                -Message ('Unexpected error while scanning this source; continuing with the next source: ' + $inner.Message)
            Write-Log -Level DETAIL -Message ('Scan exception stack: ' + $_.ScriptStackTrace)
        }
        $watch.Stop()
        $items = $c.ItemsExported - $beforeItems
        $errors = $s.ErrorCount - $beforeErrors
        $level = 'OK'
        if ($errors -gt 0) { $level = 'WARN' }
        Write-Log -Level $level -Message ('        -> {0} items exported, {1} errors, {2}' -f (Format-Count $items), $errors, (Format-Duration $watch.Elapsed))
        Update-ScanProgress -Force
    }
}

function Invoke-RecoveryPass {
    # Child roots that were "covered" by a parent whose scan could not list one of their ancestor
    # folders are validated and scanned on their own.
    $s = $script:State
    if ($s.FailedDirectories.Count -eq 0) { return }
    $recover = New-Object 'System.Collections.Generic.List[object]'
    foreach ($candidate in $s.Candidates) {
        if ($candidate.Status -ne 'Covered') { continue }
        $hit = $s.FailedDirectories.ContainsKey($candidate.CanonicalPath)
        if (-not $hit) {
            foreach ($ancestor in (Get-PathAncestors $candidate.CanonicalPath)) {
                if ($s.FailedDirectories.ContainsKey($ancestor)) { $hit = $true; break }
            }
        }
        if ($hit) {
            $candidate.Status = 'Pending'
            $candidate.IsRecovery = $true
            # The folder item itself was already exported by its parent listing.
            $candidate.SkipRootItem = $s.FailedDirectories.ContainsKey($candidate.CanonicalPath)
            $candidate.CoveredByRow = ''
            $candidate.CoveredByPath = ''
            $s.Counters.CoveredRows--
            $recover.Add($candidate)
        }
    }
    if ($recover.Count -eq 0) { return }
    Write-Log -Level HEADER -Message ''
    Write-Log -Level HEADER -Message ('{0} Excel row(s) lie below folders that could not be listed. Checking them as independent roots...' -f $recover.Count)
    $before = $s.Roots.Count
    Invoke-SourcePlanning -Candidates $recover -Recovery
    $newRoots = New-Object 'System.Collections.Generic.List[object]'
    for ($i = $before; $i -lt $s.Roots.Count; $i++) { $newRoots.Add($s.Roots[$i]) }
    if ($newRoots.Count -gt 0) { Invoke-RootScans -Roots $newRoots.ToArray() -Label 'Recovered source' }
}

function Write-SourcesReport {
    $s = $script:State
    if (-not $s.Paths.SourcesCsv) { return }
    $writer = New-Utf8Writer -Path $s.Paths.SourcesCsv
    try {
        $writer.WriteLine((ConvertTo-CsvLine -Fields $script:SourceColumns))
        foreach ($cand in ($s.Candidates | Sort-Object -Property ExcelRow)) {
            $accessPath = ''; $method = ''; $kind = ''; $category = ''; $code = ''; $attempts = ''
            if ($null -ne $cand.Access) {
                $accessPath = $cand.Access.AccessPath
                $method = $cand.Access.Method
                if ($cand.Access.Accessible) { if ($cand.Access.IsDirectory) { $kind = 'Folder' } else { $kind = 'File' } }
                $category = $cand.Access.Category
                if ($cand.Access.Code) { $code = [string]$cand.Access.Code }
                $attempts = $cand.Access.AttemptSummary
            }
            $origin = ''
            if ($null -ne $cand.OriginFiles) { $origin = ([double]$cand.OriginFiles).ToString($script:Invariant) }
            $fields = @(
                $cand.ExcelRow.ToString($script:Invariant), $cand.Status, $cand.Detail,
                $cand.SourceFolder, $cand.UncSourceFolder, $cand.UncFolder,
                $cand.SelectedColumn, $cand.LogicalPath, $cand.CanonicalPath, $cand.PathKind, $cand.FallbackEquivalence,
                $accessPath, $method, $kind, $category, $code,
                $cand.CoveredByRow, $cand.CoveredByPath, $cand.DuplicateOfRow, $origin, $attempts
            )
            $writer.WriteLine((ConvertTo-CsvLine -Fields $fields))
        }
    }
    finally { $writer.Dispose() }
}

function Set-ExcelEstimate {
    $s = $script:State
    $c = $s.Counters
    $c.ExcelEstimateFiles = [double]0
    $c.ExcelEstimateRows = 0
    foreach ($root in $s.Roots) {
        if ($null -ne $root.OriginFiles) { $c.ExcelEstimateFiles += [double]$root.OriginFiles; $c.ExcelEstimateRows++ }
    }
}

function Invoke-InventoryPipeline {
    param([object]$Rows, [switch]$PlanOnly)
    $s = $script:State
    $c = $s.Counters
    Write-Log -Level HEADER -Message ''
    Write-Log -Level HEADER -Message 'Preparing source list...'
    Build-SourceCandidates -Rows $Rows
    Write-Log -Message ('Rows marked "To Be Uploaded?" = Yes : ' + (Format-Count $c.YesRows))
    Write-Log -Message ('  without any source path (warning)  : ' + (Format-Count $c.RowsWithoutSourcePath))
    Write-Log -Message ('  with an invalid source path        : ' + (Format-Count $c.RowsWithInvalidPath))
    Write-Log -Message ('  valid source candidates            : ' + (Format-Count $c.ValidCandidates))
    Write-Log -Message ('Unique source locations              : ' + (Format-Count $c.UniqueSourcePaths))
    if ($c.ValidCandidates -eq 0) { return }

    Write-Log -Level HEADER -Message ''
    Write-Log -Level HEADER -Message 'Checking access to source roots (parent folders first)...'
    Invoke-SourcePlanning -Candidates $s.Candidates
    Set-ExcelEstimate
    Write-Log -Message ('Source roots checked                 : ' + (Format-Count $c.RootsEvaluated))
    Write-Log -Message ('  accessible                         : ' + (Format-Count $c.AccessibleRoots))
    Write-Log -Message ('  inaccessible                       : ' + (Format-Count $c.InaccessibleRoots))
    Write-Log -Message ('Rows covered by a parent root        : ' + (Format-Count $c.CoveredRows))
    Write-Log -Message ('Duplicate rows                       : ' + (Format-Count $c.DuplicateRows))
    if ($c.ExcelEstimateRows -gt 0) {
        Write-Log -Message ('Excel "# Origin Files" estimate      : ~' + (Format-Count $c.ExcelEstimateFiles) + ' files (estimate only, from ' + $c.ExcelEstimateRows + ' root rows)')
    }
    if ($PlanOnly) { return }

    if ($s.Roots.Count -gt 0) {
        Write-Log -Level HEADER -Message ''
        Write-Log -Level HEADER -Message ('Scanning {0} accessible source root(s)...' -f $s.Roots.Count)
        Write-Log -Message ('Output: ' + $s.Paths.InventoryCsv)
        Invoke-RootScans -Roots $s.Roots.ToArray() -Label 'Source'
        Invoke-RecoveryPass
    }
    Write-Progress -Id 1 -Activity 'Metadata inventory' -Completed
}

# ============================================================================
# Outcome and summary
# ============================================================================
function Get-RunOutcome {
    $s = $script:State
    $c = $s.Counters
    $status = ''; $title = ''; $exit = 0; $level = 'OK'; $advice = ''
    if ($s.Cancelled) {
        $status = 'Cancelled'; $title = 'CANCELLED BY THE USER'; $exit = $script:ExitCodes.Cancelled; $level = 'WARN'
    }
    elseif ($s.FatalError) {
        $status = 'FatalError'; $title = 'FAILED - FATAL ERROR'; $exit = $script:ExitCodes.FatalError; $level = 'ERROR'
        $advice = 'See the log file. If the problem is related to paths or network access, run RunDiagnostic.bat and send the diagnostic ZIP.'
    }
    elseif ($c.YesRows -eq 0) {
        $status = 'NoEligibleRows'; $title = 'NOTHING TO PROCESS - no row has "To Be Uploaded?" = Yes'; $exit = $script:ExitCodes.NothingToProcess; $level = 'WARN'
        $advice = 'Check that the correct workbook and worksheet were selected.'
    }
    elseif ($c.ValidCandidates -eq 0) {
        $status = 'NoValidSourcePaths'; $title = 'NOTHING TO PROCESS - no valid source path in the "Yes" rows'; $exit = $script:ExitCodes.NothingToProcess; $level = 'WARN'
        $advice = 'Fill "Source Folder" or "UNC Source Folder" for the rows marked Yes (see the errors CSV).'
    }
    elseif ($s.Mode -eq 'Diagnostic') {
        if ($c.AccessibleRoots -eq 0) {
            $status = 'DiagnosticAllInaccessible'; $title = 'DIAGNOSTIC: NO SOURCE ROOT IS ACCESSIBLE FROM THIS COMPUTER'; $exit = $script:ExitCodes.Failed; $level = 'ERROR'
        }
        elseif ($c.InaccessibleRoots -gt 0) {
            $status = 'DiagnosticPartial'; $title = 'DIAGNOSTIC: SOME SOURCE ROOTS ARE NOT ACCESSIBLE'; $exit = $script:ExitCodes.PartialSuccess; $level = 'WARN'
        }
        else {
            $status = 'DiagnosticOk'; $title = 'DIAGNOSTIC: ALL SOURCE ROOTS ARE ACCESSIBLE'; $exit = $script:ExitCodes.Success; $level = 'OK'
        }
        $advice = 'Send the diagnostic ZIP file to the migration team.'
    }
    elseif ($c.ItemsExported -eq 0) {
        $exit = $script:ExitCodes.Failed; $level = 'ERROR'
        if ($c.AccessibleRoots -eq 0) {
            $status = 'AllSourcesInaccessible'; $title = 'INVENTORY FAILED - NO SOURCE ROOT COULD BE ACCESSED, ZERO ITEMS EXPORTED'
        }
        else {
            $status = 'ZeroItems'; $title = 'INVENTORY FAILED - ZERO ITEMS EXPORTED'
        }
        $advice = 'The inventory CSV is empty. Run RunDiagnostic.bat on this computer and send the diagnostic ZIP file.'
    }
    elseif ($s.ErrorCount -gt 0) {
        $status = 'PartialSuccess'; $title = 'INVENTORY COMPLETED WITH ERRORS'; $exit = $script:ExitCodes.PartialSuccess; $level = 'WARN'
        $advice = 'Review the errors CSV. Items from accessible sources were exported.'
    }
    else {
        $status = 'Success'; $title = 'INVENTORY COMPLETED SUCCESSFULLY'; $exit = $script:ExitCodes.Success; $level = 'OK'
    }
    return [pscustomobject]@{ Status = $status; Title = $title; ExitCode = $exit; Level = $level; Advice = $advice }
}

function Get-SummaryLines {
    param([object]$Outcome)
    $s = $script:State
    $c = $s.Counters
    $lines = New-Object 'System.Collections.Generic.List[string]'
    $bar = '=' * 78
    $lines.Add($bar)
    $lines.Add(' RESULT: ' + $Outcome.Title)
    $lines.Add(' Exit code: ' + $Outcome.ExitCode + ' (' + $Outcome.Status + ')')
    $lines.Add($bar)
    $lines.Add(' Excel workbook                   : ' + $s.Excel.Path)
    $lines.Add(' Worksheet                        : ' + $s.Excel.SheetName)
    $lines.Add(' Excel data rows read             : ' + (Format-Count $s.Excel.DataRowsRead) + ' (blank rows: ' + (Format-Count $s.Excel.BlankRows) + ')')
    $lines.Add(' Rows marked Yes                  : ' + (Format-Count $c.YesRows))
    $lines.Add(' Rows marked Yes without a path   : ' + (Format-Count $c.RowsWithoutSourcePath))
    $lines.Add(' Rows with an invalid path        : ' + (Format-Count $c.RowsWithInvalidPath))
    $lines.Add(' Valid source candidates          : ' + (Format-Count $c.ValidCandidates))
    $lines.Add(' Unique source locations          : ' + (Format-Count $c.UniqueSourcePaths) + ' (duplicate rows: ' + (Format-Count $c.DuplicateRows) + ')')
    $lines.Add(' Rows covered by a parent root    : ' + (Format-Count $c.CoveredRows))
    $lines.Add(' Source roots checked             : ' + (Format-Count $c.RootsEvaluated))
    $lines.Add('   accessible                     : ' + (Format-Count $c.AccessibleRoots))
    $lines.Add('   inaccessible                   : ' + (Format-Count $c.InaccessibleRoots))
    if ($c.RecoveredRoots -gt 0) { $lines.Add('   recovered child roots          : ' + (Format-Count $c.RecoveredRoots)) }
    $inaccessibleByCategory = @{}
    foreach ($cand in $s.Candidates) {
        if ($cand.Status -eq 'Inaccessible' -and $null -ne $cand.Access) {
            $key = [string]$cand.Access.Category
            if ($inaccessibleByCategory.ContainsKey($key)) { $inaccessibleByCategory[$key]++ } else { $inaccessibleByCategory[$key] = 1 }
        }
    }
    foreach ($key in ($inaccessibleByCategory.Keys | Sort-Object)) {
        $lines.Add('     ' + $key.PadRight(29) + ': ' + (Format-Count $inaccessibleByCategory[$key]))
    }
    if ($s.Mode -ne 'Diagnostic') {
        $lines.Add(' Folders exported                 : ' + (Format-Count $c.FoldersExported))
        $lines.Add(' Files exported                   : ' + (Format-Count $c.FilesExported))
        $lines.Add(' Total items exported             : ' + (Format-Count $c.ItemsExported))
        $lines.Add(' Total file size                  : ' + (Format-Bytes $c.TotalBytes))
        $lines.Add(' Folders that could not be listed : ' + (Format-Count $c.DirectoryErrors))
        $lines.Add(' Links/junctions not followed     : ' + (Format-Count $c.ReparsePointsNotFollowed))
        if ($c.ExcelEstimateRows -gt 0) {
            $lines.Add(' Excel "# Origin Files" estimate  : ~' + (Format-Count $c.ExcelEstimateFiles) + ' files (estimate from Excel, not a measurement)')
        }
    }
    $lines.Add(' Errors                           : ' + (Format-Count $s.ErrorCount))
    $lines.Add(' Warnings                         : ' + (Format-Count $s.WarningCount))
    foreach ($key in ($s.CategoryCounts.Keys | Sort-Object)) {
        $lines.Add('   ' + $key.PadRight(31) + ': ' + (Format-Count $s.CategoryCounts[$key]))
    }
    $lines.Add(' Duration                         : ' + (Format-Duration ((Get-Date) - $s.StartTime)))
    $lines.Add(' File system engine               : ' + $s.EngineDetail)
    $lines.Add(' PowerShell                       : ' + $PSVersionTable.PSVersion.ToString() + ' ' + [string]$PSVersionTable['PSEdition'])
    $lines.Add($bar)
    if ($s.Mode -ne 'Diagnostic' -and $s.Paths.InventoryCsv) { $lines.Add(' Inventory CSV : ' + $s.Paths.InventoryCsv) }
    if ($s.Paths.LocalizedCsv) { $lines.Add(' Local-decimal : ' + $s.Paths.LocalizedCsv) }
    if ($s.Paths.IssueCsv) { $lines.Add(' Errors CSV    : ' + $s.Paths.IssueCsv) }
    if ($s.Paths.SourcesCsv) { $lines.Add(' Sources CSV   : ' + $s.Paths.SourcesCsv) }
    if ($s.Paths.DiagReportTxt) { $lines.Add(' Diag. report  : ' + $s.Paths.DiagReportTxt) }
    if ($s.Paths.DiagZip) { $lines.Add(' SEND THIS ZIP : ' + $s.Paths.DiagZip) }
    if ($s.Paths.SupportZip) { $lines.Add(' SEND THIS ZIP : ' + $s.Paths.SupportZip + ' (summary, errors, sources, log)') }
    if ($s.Paths.LogTxt) { $lines.Add(' Log           : ' + $s.Paths.LogTxt) }
    if ($Outcome.Advice) {
        $lines.Add($bar)
        $lines.Add(' NEXT STEP: ' + $Outcome.Advice)
    }
    $lines.Add($bar)
    return , $lines
}

function Write-FinalSummary {
    param([object]$Outcome)
    $s = $script:State
    $lines = Get-SummaryLines -Outcome $Outcome
    if ($Outcome.Level -eq 'ERROR' -and -not $s.Options.Quiet) {
        Write-Host ''
        Write-Host ('#' * 78) -ForegroundColor Red
        Write-Host ('#  ' + $Outcome.Title) -ForegroundColor Red
        Write-Host ('#' * 78) -ForegroundColor Red
    }
    Write-Log -Level HEADER -Message ''
    foreach ($line in $lines) {
        $level = 'HEADER'
        if ($line.StartsWith(' RESULT:') -or $line.StartsWith(' NEXT STEP:') -or $line.StartsWith(' SEND THIS ZIP')) { $level = $Outcome.Level }
        Write-Log -Level $level -Message $line
    }
    if ($s.Paths.SummaryTxt) {
        try {
            $writer = New-Utf8Writer -Path $s.Paths.SummaryTxt
            try { foreach ($line in $lines) { $writer.WriteLine($line) } } finally { $writer.Dispose() }
        }
        catch { Write-Log -Level WARN -Message ('Could not write the summary file: ' + $_.Exception.Message) }
    }
}

# ============================================================================
# Environment and diagnostics
# ============================================================================
function Get-EnvironmentInfo {
    $s = $script:State
    $info = [ordered]@{}
    $info['Script version'] = $script:ScriptVersion
    $info['Run mode'] = $s.Mode
    $info['Local time'] = Get-SafeValue { (Get-Date).ToString('yyyy-MM-dd HH:mm:ss zzz', $script:Invariant) }
    $info['Computer name'] = Get-SafeValue { $env:COMPUTERNAME }
    $info['Windows user'] = Get-SafeValue { [System.Security.Principal.WindowsIdentity]::GetCurrent().Name }
    $info['Session name'] = Get-SafeValue { $env:SESSIONNAME }
    $info['Elevated (Run as administrator)'] = Get-SafeValue { Test-IsElevated }
    $info['PowerShell version'] = Get-SafeValue { $PSVersionTable.PSVersion.ToString() }
    $info['PowerShell edition'] = Get-SafeValue { $PSVersionTable['PSEdition'] }
    $info['CLR version'] = Get-SafeValue { $PSVersionTable['CLRVersion'] }
    $info['.NET runtime'] = Get-SafeValue { [System.Runtime.InteropServices.RuntimeInformation]::FrameworkDescription }
    $info['.NET Framework 4.x release key'] = Get-SafeValue { Get-RegistryValue -Path 'HKLM:\SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full' -Name 'Release' }
    $info['Windows'] = Get-SafeValue {
        $key = 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion'
        (Get-RegistryValue $key 'ProductName') + ' ' + (Get-RegistryValue $key 'DisplayVersion') + ' build ' + (Get-RegistryValue $key 'CurrentBuild') + '.' + (Get-RegistryValue $key 'UBR')
    }
    $info['OS version'] = Get-SafeValue { [Environment]::OSVersion.VersionString }
    $info['64-bit OS / 64-bit process'] = Get-SafeValue { ([string][Environment]::Is64BitOperatingSystem) + ' / ' + ([string][Environment]::Is64BitProcess) }
    $info['PowerShell host'] = Get-SafeValue { $Host.Name }
    $info['Process path'] = Get-SafeValue { [System.Diagnostics.Process]::GetCurrentProcess().Path }
    $info['Thread apartment'] = Get-SafeValue { [System.Threading.Thread]::CurrentThread.GetApartmentState() }
    $info['Language mode'] = Get-SafeValue { $ExecutionContext.SessionState.LanguageMode }
    $info['Execution policy (effective)'] = Get-SafeValue { Get-ExecutionPolicy }
    $info['Culture / UI culture'] = Get-SafeValue { [System.Globalization.CultureInfo]::CurrentCulture.Name + ' / ' + [System.Globalization.CultureInfo]::CurrentUICulture.Name }
    $info['Decimal separator / list separator'] = Get-SafeValue { [System.Globalization.CultureInfo]::CurrentCulture.NumberFormat.NumberDecimalSeparator + ' / ' + [System.Globalization.CultureInfo]::CurrentCulture.TextInfo.ListSeparator }
    $info['Current directory'] = Get-SafeValue { (Get-Location).Path }
    $info['Script folder'] = $script:ScriptBase
    $info['File system engine'] = $s.EngineDetail
    $info['.NET accepts \\?\ paths (tested on \\?\%SystemRoot%)'] = Get-SafeValue { $s.DotNetExtendedPathSupport }
    $info['AppContext Switch.System.IO.UseLegacyPathHandling'] = Get-SafeValue {
        $value = $false
        if ([System.AppContext]::TryGetSwitch('Switch.System.IO.UseLegacyPathHandling', [ref]$value)) { [string]$value } else { 'not set (host default)' }
    }
    $info['AppContext Switch.System.IO.BlockLongPaths'] = Get-SafeValue {
        $value = $false
        if ([System.AppContext]::TryGetSwitch('Switch.System.IO.BlockLongPaths', [ref]$value)) { [string]$value } else { 'not set (host default)' }
    }
    $info['LongPathsEnabled (registry)'] = Get-SafeValue { Get-RegistryValue -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\FileSystem' -Name 'LongPathsEnabled' }
    $info['EnableLinkedConnections (registry)'] = Get-SafeValue { Get-RegistryValue -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' -Name 'EnableLinkedConnections' }
    $info['Excel library'] = $s.Excel.Library
    return $info
}

function Write-EnvironmentToLog {
    param([System.Collections.Specialized.OrderedDictionary]$Info)
    foreach ($key in $Info.Keys) { Write-Log -Level DETAIL -Message ('ENV ' + $key + ' = ' + $Info[$key]) }
}

function Test-TcpPort {
    param([string]$HostName, [int]$Port = 445, [int]$TimeoutMs = 3000)
    $client = New-Object System.Net.Sockets.TcpClient
    try {
        $async = $client.BeginConnect($HostName, $Port, $null, $null)
        if (-not $async.AsyncWaitHandle.WaitOne($TimeoutMs)) { return ('TIMEOUT after ' + $TimeoutMs + ' ms') }
        $client.EndConnect($async)
        return 'OPEN'
    }
    catch { return ('FAILED: ' + (Get-InnermostException $_.Exception).Message) }
    finally { $client.Close() }
}

function Resolve-HostDiagnostic {
    param([string]$HostName)
    $dns = Get-SafeValue { @([System.Net.Dns]::GetHostAddresses($HostName) | ForEach-Object { $_.IPAddressToString }) }
    $tcp = Test-TcpPort -HostName $HostName
    return [pscustomobject]@{ Host = $HostName; Dns = $dns; Tcp445 = $tcp }
}

function Invoke-MatrixTest {
    param([scriptblock]$Test)
    $watch = [System.Diagnostics.Stopwatch]::StartNew()
    $row = [pscustomobject]@{ Result = ''; Win32Code = ''; Category = ''; ExceptionType = ''; Message = ''; DurationMs = 0 }
    try {
        $outcome = & $Test
        if ($outcome -isnot [hashtable]) { $outcome = @{ Result = [string]$outcome } }
        $row.Result = [string]$outcome['Result']
        if ($outcome.ContainsKey('Code') -and $outcome['Code']) {
            $row.Win32Code = [string]$outcome['Code']
            $row.Category = Get-ErrorCategory ([int]$outcome['Code'])
            $row.Message = Get-Win32Message ([int]$outcome['Code'])
        }
        if ($outcome.ContainsKey('Message') -and $outcome['Message']) { $row.Message = [string]$outcome['Message'] }
    }
    catch {
        $inner = Get-InnermostException $_.Exception
        $code = Get-ExceptionWin32Code $inner
        $row.Result = 'EXCEPTION'
        if ($code) { $row.Win32Code = [string]$code; $row.Category = Get-ErrorCategory $code }
        $row.ExceptionType = $inner.GetType().FullName
        $row.Message = $inner.Message
    }
    $watch.Stop()
    $row.DurationMs = [long]$watch.ElapsedMilliseconds
    return $row
}

function Invoke-AccessMatrix {
    # Tests one location with every method and path form. Read-only.
    param([string]$Scope, [AllowEmptyString()][string]$ExcelRow, [string]$LogicalPath, [string]$Variant, [string]$PlainPath, [System.IO.StreamWriter]$Writer)
    $s = $script:State
    $results = New-Object 'System.Collections.Generic.List[object]'
    $server = ''
    if (Test-ServerChecksEnabled) { $server = Get-AttemptServer -Path $PlainPath }
    if ($server -and (Get-ServerStatus -Server $server).Down) {
        $row = [pscustomobject]@{
            Scope = $Scope; ExcelRow = $ExcelRow; LogicalPath = $LogicalPath; Variant = $Variant; Form = 'Any'; TestedPath = $PlainPath
            Method = 'All methods'; Result = 'SKIPPED'; Win32Code = ''; Category = 'ServerUnreachable'; ExceptionType = ''
            Message = ('Not tested: ' + (Get-ServerStatus -Server $server).Reason); DurationMs = 0
        }
        $results.Add($row)
        if ($null -ne $Writer) {
            $fields = New-Object 'System.Collections.Generic.List[object]'
            foreach ($column in $script:DiagnosticTestColumns) { $fields.Add($row.$column) }
            $Writer.WriteLine((ConvertTo-CsvLine -Fields $fields.ToArray()))
        }
        return , $results
    }
    $forms = @(@('Plain', $PlainPath), @('Extended', (ConvertTo-ExtendedPath $PlainPath)))
    $win32 = [bool]('MetadataInventoryNative.Win32Fs' -as [type])
    foreach ($form in $forms) {
        $p = [string]$form[1]
        $tests = New-Object 'System.Collections.Generic.List[object]'
        if ($win32) {
            $tests.Add(@('Win32 GetFileAttributesExW', { $code = 0; $e = [MetadataInventoryNative.Win32Fs]::GetEntry($p, [ref]$code); if ($null -ne $e) { @{ Result = ('OK (attributes: ' + (Format-FileAttributes ([long]$e.Attributes)) + ')') } } else { @{ Result = 'FAIL'; Code = $code } } }))
            $tests.Add(@('Win32 FindFirstFileExW (list)', { $code = [MetadataInventoryNative.Win32Fs]::ProbeDirectory($p); if ($code -eq 0) { @{ Result = 'OK (entries found)' } } elseif ($code -eq 2 -or $code -eq 18) { @{ Result = 'OK (empty or no entries)' } } else { @{ Result = 'FAIL'; Code = $code } } }))
        }
        $tests.Add(@('.NET Directory.Exists', { @{ Result = ([string][System.IO.Directory]::Exists($p)).ToUpperInvariant() } }))
        $tests.Add(@('.NET File.Exists', { @{ Result = ([string][System.IO.File]::Exists($p)).ToUpperInvariant() } }))
        $tests.Add(@('.NET File.GetAttributes', { @{ Result = ('OK (' + [string][System.IO.File]::GetAttributes($p) + ')') } }))
        $tests.Add(@('.NET DirectoryInfo.EnumerateFileSystemInfos', { $en = (New-Object System.IO.DirectoryInfo($p)).EnumerateFileSystemInfos().GetEnumerator(); $has = $en.MoveNext(); @{ Result = ('OK (has entries: ' + $has + ')') } }))
        $tests.Add(@('PowerShell Test-Path -LiteralPath', { @{ Result = ([string](Test-Path -LiteralPath $p)).ToUpperInvariant() } }))
        $tests.Add(@('PowerShell Get-Item -LiteralPath', { $item = Get-Item -LiteralPath $p -Force -ErrorAction Stop; @{ Result = ('OK (' + $item.GetType().Name + ')') } }))
        foreach ($test in $tests) {
            $outcome = Invoke-MatrixTest -Test $test[1]
            $row = [pscustomobject]@{
                Scope = $Scope; ExcelRow = $ExcelRow; LogicalPath = $LogicalPath; Variant = $Variant; Form = [string]$form[0]; TestedPath = $p
                Method = [string]$test[0]; Result = $outcome.Result; Win32Code = $outcome.Win32Code; Category = $outcome.Category
                ExceptionType = $outcome.ExceptionType; Message = $outcome.Message; DurationMs = $outcome.DurationMs
            }
            $results.Add($row)
            if ($null -ne $Writer) {
                $fields = New-Object 'System.Collections.Generic.List[object]'
                foreach ($column in $script:DiagnosticTestColumns) { $fields.Add($row.$column) }
                $Writer.WriteLine((ConvertTo-CsvLine -Fields $fields.ToArray()))
            }
        }
    }
    return , $results
}

function Get-NetUseOutput {
    $ErrorActionPreference = 'Continue'
    try {
        $output = & "$env:SystemRoot\System32\net.exe" use 2>&1 | Out-String
        return $output.Trim()
    }
    catch { return ('<net use failed: ' + $_.Exception.Message + '>') }
}

function Invoke-DiagnosticPipeline {
    param([object]$Workbook)
    $s = $script:State
    $c = $s.Counters
    $report = New-Object 'System.Collections.Generic.List[string]'
    $findings = New-Object 'System.Collections.Generic.List[string]'
    $report.Add('METADATA INVENTORY - DIAGNOSTIC REPORT')
    $report.Add('Generated: ' + (Get-Date).ToString('yyyy-MM-dd HH:mm:ss', $script:Invariant) + ' | script version ' + $script:ScriptVersion)
    $report.Add('This report was produced without uploading, modifying, moving or deleting any file.')
    $report.Add('It contains computer, user, drive and server names. It contains no passwords or tokens.')
    $report.Add('')

    # 1. Environment
    Write-Log -Level HEADER -Message 'Collecting environment information...'
    $environment = Get-EnvironmentInfo
    $report.Add('=== 1. ENVIRONMENT ===')
    foreach ($key in $environment.Keys) { $report.Add(('{0,-55}: {1}' -f $key, $environment[$key])) }
    $report.Add('')
    if ($s.DotNetExtendedPathSupport -eq $false) {
        $findings.Add('The .NET runtime of this PowerShell session REJECTS \\?\ extended-length paths ([IO.Directory]::Exists returns False for \\?\' + $env:SystemRoot + '). The previous script version converted every source to \\?\ form before calling [IO.Directory]::Exists, so it reported existing folders as "Source path not found". Version 2 uses the native Win32 engine and also tries plain paths.')
    }
    if ($s.Engine -ne 'Win32') { $findings.Add('The native Win32 engine could not be used: ' + $s.EngineDetail + '. Long paths may fail with the .NET fallback engine.') }
    if (Test-IsElevated) { $findings.Add('PowerShell runs ELEVATED (Run as administrator). Drive letters mapped in the normal user session are usually NOT visible in an elevated session. Start the BAT file normally (double-click, not "Run as administrator").') }

    # 2. Excel and candidates (also performs the real access checks, exactly as the inventory does)
    $report.Add('=== 2. EXCEL WORKBOOK ===')
    $report.Add('Workbook: ' + $s.Excel.Path)
    $report.Add('Worksheet: ' + $s.Excel.SheetName)
    $report.Add('Columns found: ' + [string]::Join(' | ', $s.Excel.Headers))
    $report.Add('Data rows read: ' + $s.Excel.DataRowsRead + ' (blank rows: ' + $s.Excel.BlankRows + ')')
    Invoke-InventoryPipeline -Rows $Workbook.Rows -PlanOnly
    $report.Add('Rows marked Yes: ' + $c.YesRows + ' | without path: ' + $c.RowsWithoutSourcePath + ' | invalid path: ' + $c.RowsWithInvalidPath + ' | valid: ' + $c.ValidCandidates)
    $report.Add('Unique source locations: ' + $c.UniqueSourcePaths + ' | duplicate rows: ' + $c.DuplicateRows + ' | covered by an accessible parent: ' + $c.CoveredRows)
    $report.Add('Source roots checked: ' + $c.RootsEvaluated + ' | accessible: ' + $c.AccessibleRoots + ' | inaccessible: ' + $c.InaccessibleRoots)
    $report.Add('')

    # 3. Drives
    Write-Log -Level HEADER -Message 'Inspecting drive mappings...'
    $report.Add('=== 3. DRIVE MAPPINGS ===')
    $letters = New-Object 'System.Collections.Generic.SortedSet[string]'
    foreach ($cand in $s.Candidates) {
        if ($null -ne $cand.Primary -and $cand.Primary.Kind -eq 'Drive') { [void]$letters.Add($cand.Primary.DriveLetter) }
    }
    try { foreach ($d in [System.IO.DriveInfo]::GetDrives()) { if ([string]$d.DriveType -eq 'Network') { [void]$letters.Add($d.Name.Substring(0, 1).ToUpperInvariant()) } } } catch { }
    try { foreach ($k in @(Get-ChildItem -LiteralPath 'HKCU:\Network' -ErrorAction Stop)) { [void]$letters.Add($k.PSChildName.Substring(0, 1).ToUpperInvariant()) } } catch { }
    foreach ($letter in $letters) {
        $info = Get-DriveMappingInfo -Letter $letter
        $usage = @($s.Candidates | Where-Object { $null -ne $_.Primary -and $_.Primary.Kind -eq 'Drive' -and $_.Primary.DriveLetter -eq $letter }).Count
        $report.Add(('Drive {0}: used by {1} Excel rows' -f $letter, $usage))
        $report.Add('    DriveInfo type          : ' + $info.DriveType + ' (available: ' + $info.IsAvailable + ')')
        $report.Add('    WNetGetConnection       : ' + $info.WNetRemoteName + ' [' + $info.WNetStatus + ']')
        $report.Add('    Get-PSDrive DisplayRoot : ' + $info.PSDriveRoot)
        $report.Add('    HKCU\Network RemotePath : ' + $info.RegistryRemotePath)
        $report.Add('    Resolved UNC            : ' + $info.ResolvedUnc + ' (' + $info.ResolvedFrom + ')')
        if ($s.ImpliedDriveMappings.ContainsKey($letter)) {
            $table = $s.ImpliedDriveMappings[$letter]
            foreach ($prefix in $table.Keys) {
                $match = 'no local mapping to compare'
                if ($info.ResolvedUnc) { if (Test-SameUncPath $info.ResolvedUnc $prefix) { $match = 'MATCHES the local mapping' } else { $match = 'DIFFERS from the local mapping' } }
                $report.Add('    Excel implies           : ' + $prefix + ' (' + $table[$prefix] + ' rows) - ' + $match)
                if ($match -like 'DIFFERS*') { $findings.Add('Drive ' + $letter + ': maps to ' + $info.ResolvedUnc + ' on this computer, but the Excel UNC columns imply ' + $prefix + '.') }
            }
        }
        if ($usage -gt 0 -and -not $info.IsAvailable) {
            $text = 'Drive ' + $letter + ': is used by ' + $usage + ' Excel rows but is NOT available in this PowerShell session.'
            if ($info.RegistryRemotePath) { $text += ' It is configured as a persistent mapping to ' + $info.RegistryRemotePath + ' (HKCU\Network), so it may be disconnected, or PowerShell runs in a different logon session (elevated).' }
            $text += ' The Excel UNC fallback is used where it is equivalent.'
            $findings.Add($text)
        }
    }
    $report.Add('')
    $report.Add('--- net use ---')
    foreach ($line in ((Get-NetUseOutput) -split "`r?`n")) { $report.Add('    ' + $line) }
    $report.Add('')

    # 4. Servers
    Write-Log -Level HEADER -Message 'Testing name resolution and SMB port 445 of the servers...'
    $report.Add('=== 4. SERVERS (DNS and TCP 445) ===')
    $servers = New-Object 'System.Collections.Generic.SortedSet[string]' ([System.StringComparer]::OrdinalIgnoreCase)
    $shares = New-Object 'System.Collections.Generic.SortedSet[string]' ([System.StringComparer]::OrdinalIgnoreCase)
    $uncValues = New-Object 'System.Collections.Generic.List[string]'
    foreach ($cand in $s.Candidates) {
        if ($null -eq $cand.Primary) { continue }
        if ($cand.Primary.Kind -eq 'UNC') { $uncValues.Add($cand.Primary.Normalized) }
        foreach ($fb in $cand.Fallbacks) { if ($fb.Path.Kind -eq 'UNC') { $uncValues.Add($fb.Path.Normalized) } }
    }
    foreach ($letter in $letters) { $di = Get-DriveMappingInfo -Letter $letter; if ($di.ResolvedUnc) { $uncValues.Add($di.ResolvedUnc) } }
    foreach ($u in $uncValues) {
        $parts = Split-UncServer $u
        [void]$servers.Add($parts.Server)
        $rootLength = Get-PathRootLength $u
        [void]$shares.Add($u.Substring(0, $rootLength))
    }
    $serverCount = 0
    foreach ($server in $servers) {
        $serverCount++
        if ($serverCount -gt 25) { $report.Add('(more servers omitted)'); break }
        $h = Get-ServerStatus -Server $server
        $report.Add(('{0}: DNS = {1} | TCP 445 = {2}{3}' -f $h.Server, $h.Dns, $h.Tcp445, $(if ($h.Down) { ' | MARKED UNREACHABLE: ' + $h.Reason } else { '' })))
        if ($h.Dns -like '<error*' -or -not $h.Dns) { $findings.Add('Server ' + $server + ' cannot be resolved by DNS from this computer: ' + $h.Dns) }
        elseif ($h.Tcp445 -ne 'OPEN') { $findings.Add('Server ' + $server + ' resolves (' + $h.Dns + ') but SMB port 445 is not reachable: ' + $h.Tcp445) }
    }
    $report.Add('')

    # 5. Access matrix
    Write-Log -Level HEADER -Message 'Testing every access method on the share roots and top-level source roots...'
    $testsWriter = New-Utf8Writer -Path $s.Paths.DiagTestsCsv
    try {
        $testsWriter.WriteLine((ConvertTo-CsvLine -Fields $script:DiagnosticTestColumns))
        $report.Add('=== 5. SHARE ROOTS ===')
        $shareCount = 0
        foreach ($share in $shares) {
            $shareCount++
            if ($shareCount -gt 50) { $report.Add('(more shares omitted)'); break }
            $rows = Invoke-AccessMatrix -Scope 'ShareRoot' -ExcelRow '' -LogicalPath $share -Variant 'Share' -PlainPath $share -Writer $testsWriter
            $report.Add($share + ' : ' + (Format-MatrixVerdict $rows))
        }
        $report.Add('')

        $report.Add('=== 6. TOP-LEVEL SOURCE ROOTS (not inside another Excel path) ===')
        $canonicalSet = New-Object 'System.Collections.Generic.HashSet[string]' ([System.StringComparer]::OrdinalIgnoreCase)
        foreach ($cand in $s.Candidates) { if ($cand.CanonicalPath -and $cand.Status -ne 'NoSourcePath' -and $cand.Status -ne 'InvalidPath') { [void]$canonicalSet.Add($cand.CanonicalPath) } }
        $topLevel = New-Object 'System.Collections.Generic.List[object]'
        $seenTop = New-Object 'System.Collections.Generic.HashSet[string]' ([System.StringComparer]::OrdinalIgnoreCase)
        foreach ($cand in ($s.Candidates | Sort-Object -Property ExcelRow)) {
            if (-not $cand.CanonicalPath -or $cand.Status -eq 'NoSourcePath' -or $cand.Status -eq 'InvalidPath') { continue }
            $isTop = $true
            foreach ($ancestor in (Get-PathAncestors $cand.CanonicalPath)) { if ($canonicalSet.Contains($ancestor)) { $isTop = $false; break } }
            if ($isTop -and $seenTop.Add($cand.CanonicalPath)) { $topLevel.Add($cand) }
        }
        $report.Add('Top-level source roots: ' + $topLevel.Count + ' (matrix limited to ' + $s.Options.DiagnosticMaxRoots + ')')
        $index = 0
        foreach ($cand in $topLevel) {
            $index++
            if ($index -gt $s.Options.DiagnosticMaxRoots) { $report.Add('(more roots omitted; use -DiagnosticMaxRoots to raise the limit)'); break }
            Write-Progress -Id 1 -Activity 'Testing access methods' -Status ('Root {0} of {1}' -f $index, [Math]::Min($topLevel.Count, $s.Options.DiagnosticMaxRoots)) -CurrentOperation $cand.LogicalPath -PercentComplete ([int]([Math]::Min(100, $index * 100.0 / [Math]::Max(1, [Math]::Min($topLevel.Count, $s.Options.DiagnosticMaxRoots)))))
            $report.Add('')
            $report.Add(('Row {0}: {1}' -f $cand.ExcelRow, $cand.LogicalPath))
            $report.Add('    Status in plan : ' + $cand.Status + $(if ($cand.Detail) { ' - ' + $cand.Detail } else { '' }))
            if ($null -ne $cand.Access) {
                if ($cand.Access.Accessible) { $report.Add('    Access method  : ' + $cand.Access.Method + ' -> ' + $cand.Access.AccessPath) }
                $report.Add('    Attempts       : ' + $cand.Access.AttemptSummary)
            }
            $variants = New-Object 'System.Collections.Generic.List[object]'
            $variants.Add(@('Original', $cand.Primary.Normalized))
            if ($cand.Primary.Kind -eq 'Drive') {
                $di = Get-DriveMappingInfo -Letter $cand.Primary.DriveLetter
                if ($di.ResolvedUnc) { $variants.Add(@('DriveMapping', (Join-FsPath $di.ResolvedUnc $cand.Primary.Normalized.Substring(3)))) }
            }
            foreach ($fb in $cand.Fallbacks) { $variants.Add(@(($fb.Column + ' (' + $fb.Equivalence + ')'), $fb.Path.Normalized)) }
            foreach ($variant in $variants) {
                $rows = Invoke-AccessMatrix -Scope 'SourceRoot' -ExcelRow ([string]$cand.ExcelRow) -LogicalPath $cand.LogicalPath -Variant ([string]$variant[0]) -PlainPath ([string]$variant[1]) -Writer $testsWriter
                $report.Add('    ' + ([string]$variant[0]).PadRight(40) + ' ' + [string]$variant[1])
                $report.Add('        ' + (Format-MatrixVerdict $rows))
                $legacy = Get-LegacyPathEvidence $rows
                if ($legacy) { $findings.Add('Row ' + $cand.ExcelRow + ' (' + $cand.LogicalPath + '): ' + $legacy) }
            }
            if ($null -ne $cand.Access -and $cand.Access.Accessible -and $cand.Access.IsDirectory) {
                $listing = Get-FsChildren -Path $cand.Access.AccessPath
                $dirs = 0; $files = 0
                if ($null -ne $listing.Entries) { foreach ($e in $listing.Entries) { if ($e.IsDirectory) { $dirs++ } else { $files++ } } }
                $report.Add(('    First level    : {0} folders, {1} files{2}' -f $dirs, $files, $(if ($listing.Ok) { '' } else { ' (listing error: ' + $listing.Category + ' ' + $listing.Message + ')' })))
            }
        }
        Write-Progress -Id 1 -Activity 'Testing access methods' -Completed
    }
    finally { $testsWriter.Dispose() }
    $report.Add('')

    # 7. Findings
    if ($c.InaccessibleRoots -gt 0) {
        $byCategory = @{}
        foreach ($cand in $s.Candidates) {
            if ($cand.Status -eq 'Inaccessible') {
                $k = [string]$cand.Access.Category
                if (-not $byCategory.ContainsKey($k)) { $byCategory[$k] = New-Object 'System.Collections.Generic.List[string]' }
                if ($byCategory[$k].Count -lt 5) { $byCategory[$k].Add('row ' + $cand.ExcelRow + ' ' + $cand.LogicalPath) }
            }
        }
        foreach ($k in $byCategory.Keys) {
            $description = ''
            if ($script:CategoryDescriptions.ContainsKey($k)) { $description = $script:CategoryDescriptions[$k] }
            $findings.Add('Inaccessible roots with category ' + $k + ' - ' + $description + ' Examples: ' + [string]::Join('; ', $byCategory[$k]))
        }
    }
    if ($c.AccessibleRoots -gt 0 -and $c.InaccessibleRoots -eq 0) { $findings.Add('All ' + $c.AccessibleRoots + ' source roots are accessible from this computer. The full inventory can be run.') }
    $report.Insert(5, '')
    $report.Insert(5, '=== 0. FINDINGS ===')
    $insertAt = 6
    if ($findings.Count -eq 0) { $report.Insert($insertAt, ' - No specific finding.') }
    foreach ($finding in $findings) { $report.Insert($insertAt, ' - ' + $finding); $insertAt++ }

    $writer = New-Utf8Writer -Path $s.Paths.DiagReportTxt
    try { foreach ($line in $report) { $writer.WriteLine($line) } } finally { $writer.Dispose() }
    Write-SourcesReport

    Write-Log -Level HEADER -Message ''
    Write-Log -Level HEADER -Message 'FINDINGS'
    foreach ($finding in $findings) { Write-Log -Level WARN -Message (' - ' + $finding) }
    if ($findings.Count -eq 0) { Write-Log -Message ' - No specific finding.' }
}

function Format-MatrixVerdict {
    param([object]$Rows)
    $parts = New-Object 'System.Collections.Generic.List[string]'
    foreach ($r in $Rows) {
        $short = $r.Method.Replace('PowerShell ', 'PS ').Replace(' -LiteralPath', '')
        $value = $r.Result
        if ($r.Win32Code) { $value += ' ' + $r.Win32Code }
        if ($r.Result -eq 'EXCEPTION') { $value = 'EXC ' + ($r.ExceptionType -replace '^System\.(IO\.)?', '') }
        $parts.Add($r.Form + '/' + $short + '=' + $value)
    }
    return [string]::Join('; ', $parts)
}

function Get-LegacyPathEvidence {
    param([object]$Rows)
    $plainExists = $false; $extendedExists = $null; $win32Extended = $false
    foreach ($r in $Rows) {
        if ($r.Method -eq '.NET Directory.Exists' -and $r.Form -eq 'Plain' -and $r.Result -eq 'TRUE') { $plainExists = $true }
        if ($r.Method -eq '.NET Directory.Exists' -and $r.Form -eq 'Extended') { $extendedExists = ($r.Result -eq 'TRUE') }
        if ($r.Method -eq 'Win32 GetFileAttributesExW' -and $r.Form -eq 'Extended' -and $r.Result -like 'OK*') { $win32Extended = $true }
    }
    if (($plainExists -or $win32Extended) -and $extendedExists -eq $false) {
        return 'the folder exists, but [IO.Directory]::Exists returns False for its \\?\ form. This is exactly how the previous version produced "Source path not found".'
    }
    return ''
}

# ============================================================================
# Main
# ============================================================================
function Invoke-MetadataInventoryMain {
    param(
        [string]$SheetName = 'MetaData',
        [string]$ExcelPath = '',
        [bool]$DiagnosticOnly = $false,
        [string]$OutputFolder = '',
        [bool]$LocalizedExcelCopy = $false,
        [bool]$AllowNonEquivalentFallback = $false,
        [int]$DiagnosticMaxRoots = 200,
        [string]$FileSystemEngine = 'Auto'
    )
    Initialize-InventoryState
    $s = $script:State
    if ($DiagnosticOnly) { $s.Mode = 'Diagnostic' }
    $s.Options.AllowNonEquivalentFallback = $AllowNonEquivalentFallback
    $s.Options.LocalizedExcelCopy = $LocalizedExcelCopy
    $s.Options.DiagnosticMaxRoots = $DiagnosticMaxRoots
    $exitCode = $script:ExitCodes.FatalError
    try {
        $baseOutput = $OutputFolder
        if (-not $baseOutput) { $baseOutput = Join-Path $script:ScriptBase 'MetadataReports' }
        Open-RunOutputs -BaseFolder $baseOutput

        Write-Log -Level HEADER -Message ('=' * 78)
        if ($s.Mode -eq 'Diagnostic') { Write-Log -Level HEADER -Message (' METADATA INVENTORY ' + $script:ScriptVersion + ' - DIAGNOSTIC MODE (no inventory, no upload, read-only)') }
        else { Write-Log -Level HEADER -Message (' METADATA INVENTORY ' + $script:ScriptVersion + ' - read-only, no SharePoint connection, no upload') }
        Write-Log -Level HEADER -Message ('=' * 78)

        Initialize-FileSystemEngine -Requested $FileSystemEngine
        Write-Log -Message ('File system engine : ' + $s.EngineDetail)
        Write-Log -Message ('PowerShell         : ' + $PSVersionTable.PSVersion.ToString() + ' ' + [string]$PSVersionTable['PSEdition'] + ' | elevated: ' + (Test-IsElevated))
        if ($s.DotNetExtendedPathSupport -eq $false) {
            Write-Log -Level WARN -Message 'Note: .NET in this PowerShell session rejects \\?\ paths (legacy path handling). This is handled by the native engine.'
        }
        if (Test-IsElevated) {
            Write-Log -Level WARN -Message 'Warning: PowerShell is running as administrator. Mapped drive letters may not be visible; UNC fallbacks will be used where available.'
        }

        $s.Excel.Library = Import-ExcelLibrary
        Write-Log -Level DETAIL -Message ('Excel library: ' + $s.Excel.Library)
        Write-EnvironmentToLog -Info (Get-EnvironmentInfo)

        if (-not $ExcelPath) {
            Write-Log -Message ''
            Write-Log -Message 'Select the migration Excel workbook in the dialog window (it may open behind other windows)...'
            $ExcelPath = Select-ExcelFile
            if (-not $ExcelPath) {
                $s.Cancelled = $true
                Write-Log -Level WARN -Message 'Excel selection cancelled.'
                $outcome = Get-RunOutcome
                Write-FinalSummary -Outcome $outcome
                return $outcome.ExitCode
            }
        }
        if (-not (Test-Path -LiteralPath $ExcelPath -PathType Leaf)) { throw ('Excel workbook not found: ' + $ExcelPath) }
        $s.Excel.Path = $ExcelPath
        Write-Log -Message ''
        Write-Log -Level HEADER -Message ('Reading Excel: ' + $ExcelPath + ' (worksheet "' + $SheetName + '")')
        $workbook = Read-MigrationWorkbook -Path $ExcelPath -SheetName $SheetName
        $s.Excel.SheetName = $workbook.SheetName
        $s.Excel.DataRowsRead = $workbook.DataRowsRead
        $s.Excel.BlankRows = $workbook.BlankRows
        $s.Excel.Headers = $workbook.Headers
        Write-Log -Message ('Excel data rows read: ' + (Format-Count $workbook.DataRowsRead) + ' (blank rows: ' + (Format-Count $workbook.BlankRows) + ')')

        if ($s.Mode -eq 'Diagnostic') { Invoke-DiagnosticPipeline -Workbook $workbook }
        else {
            Invoke-InventoryPipeline -Rows $workbook.Rows
            if ($null -ne $s.InventoryWriter) { $s.InventoryWriter.Flush() }
            if ($null -ne $s.LocalizedWriter) { $s.LocalizedWriter.Flush() }
            Write-SourcesReport
        }
        $outcome = Get-RunOutcome
        Write-FinalSummary -Outcome $outcome
        $exitCode = $outcome.ExitCode
    }
    catch {
        $inner = Get-InnermostException $_.Exception
        $s.FatalError = $true
        $s.FatalMessage = $inner.Message
        try {
            Add-RunIssue -Severity Error -Phase 'Fatal' -Category 'Fatal' -Message $inner.Message -ExceptionType $inner.GetType().FullName
            Write-Log -Level ERROR -Message ('FATAL ERROR: ' + $inner.Message)
            Write-Log -Level DETAIL -Message ('Exception type: ' + $inner.GetType().FullName)
            Write-Log -Level DETAIL -Message ('Script stack: ' + $_.ScriptStackTrace)
            if ($s.Mode -ne 'Diagnostic' -and $null -ne $s.Paths.SourcesCsv -and $s.Candidates.Count -gt 0) { try { Write-SourcesReport } catch { } }
            Write-FinalSummary -Outcome (Get-RunOutcome)
        }
        catch {
            Write-Host ('FATAL ERROR: ' + $inner.Message) -ForegroundColor Red
        }
        $exitCode = $script:ExitCodes.FatalError
    }
    finally {
        try { Write-Progress -Id 1 -Activity 'Metadata inventory' -Completed } catch { }
        Close-RunOutputs
        if ($s.Mode -ne 'Diagnostic' -and $s.Paths.SupportZip) {
            try {
                $small = @(@($s.Paths.SummaryTxt, $s.Paths.IssueCsv, $s.Paths.SourcesCsv, $s.Paths.LogTxt) | Where-Object { $_ -and (Test-Path -LiteralPath $_) })
                if ($small.Count -gt 0) {
                    Compress-Archive -LiteralPath $small -DestinationPath $s.Paths.SupportZip -Force -ErrorAction Stop
                    Write-Host ''
                    Write-Host ('Package to send to the migration team: ' + $s.Paths.SupportZip) -ForegroundColor Cyan
                }
            }
            catch { Write-Host ('Could not create the ZIP (' + $_.Exception.Message + '). Send the files of: ' + $s.Paths.OutputFolder) -ForegroundColor Yellow }
        }
        if ($s.Mode -eq 'Diagnostic' -and $s.Paths.OutputFolder -and (Test-Path -LiteralPath $s.Paths.OutputFolder)) {
            try {
                $files = @(Get-ChildItem -LiteralPath $s.Paths.OutputFolder -File | ForEach-Object { $_.FullName })
                if ($files.Count -gt 0) {
                    Compress-Archive -LiteralPath $files -DestinationPath $s.Paths.DiagZip -Force -ErrorAction Stop
                    Write-Host ''
                    Write-Host ('Diagnostic package created: ' + $s.Paths.DiagZip) -ForegroundColor Cyan
                }
            }
            catch {
                Write-Host ('Could not create the diagnostic ZIP (' + $_.Exception.Message + '). Send the folder instead: ' + $s.Paths.OutputFolder) -ForegroundColor Yellow
            }
        }
    }
    return $exitCode
}

# ============================================================================
# Entry point
# ============================================================================
if ($LoadFunctionsOnly) { return }

$mainResult = Invoke-MetadataInventoryMain -SheetName $SheetName -ExcelPath $ExcelPath -DiagnosticOnly ([bool]$DiagnosticOnly) `
    -OutputFolder $OutputFolder -LocalizedExcelCopy ([bool]$LocalizedExcelCopy) -AllowNonEquivalentFallback ([bool]$AllowNonEquivalentFallback) `
    -DiagnosticMaxRoots $DiagnosticMaxRoots -FileSystemEngine $FileSystemEngine
$finalExitCode = [int](@($mainResult)[-1])
exit $finalExitCode
