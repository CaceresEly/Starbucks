@echo off
setlocal EnableExtensions DisableDelayedExpansion
set "PKG=%~dp0"
set "SCRIPT=%PKG%ExportMetadataInventory.ps1"
set "MODULE=%PKG%Modules\ImportExcel\7.8.10\ImportExcel.psd1"
set "PSEXE=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
if not exist "%PSEXE%" set "PSEXE=powershell.exe"
set "RC=5"
title Metadata Inventory - Diagnostic
echo ============================================================
echo   METADATA INVENTORY - DIAGNOSTIC MODE
echo ============================================================
echo.
echo  This checks whether the source folders listed in the Excel
echo  workbook can be reached from this computer. It does NOT run
echo  the full inventory and does NOT upload or change anything.
echo.
echo  A file selection window will open. It may appear behind this
echo  window: check the taskbar if you do not see it.
echo.
echo  At the end, send the file MetadataReports\Diagnostic_*.zip
echo  to the migration team. It contains computer, user, drive and
echo  server names, but no passwords.
echo.

if not exist "%SCRIPT%" goto :missing_script
if not exist "%MODULE%" goto :missing_module

pushd "%PKG%" >nul 2>&1
"%PSEXE%" -NoProfile -NoLogo -ExecutionPolicy Bypass -STA -File "%SCRIPT%" -DiagnosticOnly %*
set "RC=%ERRORLEVEL%"
popd >nul 2>&1

echo.
echo ============================================================
if "%RC%"=="0" echo   DIAGNOSTIC: all source roots are accessible.
if "%RC%"=="1" echo   DIAGNOSTIC: some source roots are NOT accessible.
if "%RC%"=="2" echo   DIAGNOSTIC: NO source root is accessible from this computer.
if "%RC%"=="3" echo   DIAGNOSTIC: no valid "Yes" rows or source paths in the workbook.
if "%RC%"=="4" echo   DIAGNOSTIC: cancelled - no Excel workbook was selected.
if "%RC%"=="5" echo   DIAGNOSTIC: fatal error - see MetadataReports.
echo   PowerShell exit code: %RC%
echo.
echo   Please send the newest Diagnostic_*.zip file from:
echo   "%PKG%MetadataReports"
echo ============================================================
if not defined METADATA_INVENTORY_NOPAUSE if exist "%PKG%MetadataReports" start "" explorer.exe "%PKG%MetadataReports"
goto :end

:missing_script
echo ERROR: ExportMetadataInventory.ps1 was not found next to this BAT file.
echo Extract the COMPLETE ZIP package to a normal folder first, then run the BAT file
echo from the extracted folder. Do not run it from inside the ZIP viewer.
set "RC=5"
goto :end

:missing_module
echo ERROR: The bundled ImportExcel module was not found:
echo   Modules\ImportExcel\7.8.10\ImportExcel.psd1
echo Extract the COMPLETE ZIP package, keeping the folder structure.
set "RC=5"
goto :end

:end
echo.
if not defined METADATA_INVENTORY_NOPAUSE pause
endlocal & exit /b %RC%
